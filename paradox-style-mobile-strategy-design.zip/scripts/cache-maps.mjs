import { mkdir, writeFile, access } from 'node:fs/promises';
import sharp from 'sharp';

const tasks = [];
for (let z = 0; z <= 3; z++) {
  for (let x = 0; x < 2 ** z; x++) for (let y = 0; y < 2 ** z; y++) tasks.push([z, x, y]);
}
for (let z = 4; z <= 6; z++) {
  const n = 2 ** z;
  const minX = Math.floor((80 + 180) / 360 * n), maxX = Math.floor((143 + 180) / 360 * n);
  const tileY = lat => Math.floor((1 - Math.asinh(Math.tan(lat * Math.PI / 180)) / Math.PI) / 2 * n);
  for (let x = minX; x <= maxX; x++) for (let y = tileY(53); y <= tileY(14); y++) tasks.push([z, x, y]);
}
let i = 0, okay = 0, skipped = 0;
async function worker() {
  while (i < tasks.length) {
    const [z,x,y] = tasks[i++];
    const dir = `public/maps/tiles/${z}/${x}`;
    const path = `${dir}/${y}.jpg`;
    try { await access(path); skipped++; continue; } catch {}
    try {
      const res = await fetch(`https://server.arcgisonline.com/ArcGIS/rest/services/World_Physical_Map/MapServer/tile/${z}/${y}/${x}`, { signal: AbortSignal.timeout(18000) });
      if (!res.ok) continue;
      const input = Buffer.from(await res.arrayBuffer());
      const image = await sharp(input).jpeg({ quality: 86 }).toBuffer();
      await mkdir(dir, { recursive: true }); await writeFile(path, image); okay++;
    } catch (e) { console.log('tile unavailable', z, x, y); }
  }
}
await Promise.all(Array.from({ length: 14 }, worker));
console.log(`Map tiles: ${okay} cached, ${skipped} existing, ${tasks.length} total`);
await sharp('public/images/asia-relief.jpg').resize(520).modulate({ saturation: 0.35, brightness: 0.7 }).jpeg({ quality: 85 }).toFile('public/images/minimap.jpg');
