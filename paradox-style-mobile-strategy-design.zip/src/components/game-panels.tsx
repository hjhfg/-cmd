'use client';

import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, BookOpen, Check, ChevronRight, Coins, Crown, Download, Flag, Heart, Landmark, Leaf, ScrollText, Shield, Sparkles, Sprout, Swords, Users, Wheat, X } from 'lucide-react';
import { COURT_EVENTS, PROVINCES, gameDate, type GameAction, type GameState, type Province } from '@/lib/game';

export type Panel = 'court' | 'dynasty' | 'military' | 'diplomacy' | 'treasury' | 'chronicle' | 'province' | 'settings' | 'help';
type Props = {
  panel: Panel; game: GameState; province: Province; eventId: string | null; onEvent: (id: string | null) => void;
  onClose: () => void; onAction: (a: GameAction) => Promise<boolean>; busy: boolean;
  is3D: boolean; setIs3D: (v: boolean) => void; showArmies: boolean; setShowArmies: (v: boolean) => void;
  sound: boolean; setSound: (v: boolean) => void;
};
const titles: Record<Panel, [string, string]> = {
  court: ['宣政殿', 'THE IMPERIAL COURT'], dynasty: ['皇室与宗族', 'THE IMPERIAL DYNASTY'],
  military: ['枢密院', 'THE IMPERIAL ARMIES'], diplomacy: ['四方来朝', 'DIPLOMACY & RELATIONS'],
  treasury: ['三司府库', 'THE IMPERIAL TREASURY'], chronicle: ['起居注', 'CHRONICLES OF THE REIGN'],
  province: ['山河治所', 'PROVINCE & HOLDINGS'], settings: ['御前设置', 'GAME SETTINGS'], help: ['帝王之道', 'A GUIDE TO YOUR EMPIRE'],
};
const format = (n: number) => n.toLocaleString('en-US');

export default function GamePanels(props: Props) {
  const { panel, game, province, eventId, onEvent, onClose, onAction, busy } = props;
  const [courtTab, setCourtTab] = useState<'events' | 'council'>('events');
  const [recruitProvince, setRecruitProvince] = useState(province.realm === '大宋' ? province.id : 'kaifeng');
  const [confirmReset, setConfirmReset] = useState(false);
  const dialogRef = useRef<HTMLElement>(null);
  const event = COURT_EVENTS.find(e => e.id === eventId);
  const pending = COURT_EVENTS.filter(e => !game.resolvedEvents.includes(e.id));
  const title = panel === 'province' ? `${province.name} · ${province.capital}` : titles[panel][0];

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    dialogRef.current?.focus();
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') {
        const nodes = dialogRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input, select, a[href], [tabindex="0"]');
        if (!nodes?.length) return;
        const first = nodes[0], last = nodes[nodes.length - 1];
        if (e.shiftKey && (document.activeElement === first || document.activeElement === dialogRef.current)) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener('keydown', handler);
    return () => { window.removeEventListener('keydown', handler); previous?.focus(); };
  }, [onClose]);

  const exportSave = () => {
    const blob = new Blob([JSON.stringify({ title: '天命山河', exportedAt: new Date().toISOString(), state: game }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `天命山河-第${game.day + 1}日.json`; link.click(); URL.revokeObjectURL(url);
  };

  return <div className="dialog-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <section className={`game-dialog dialog-${panel}`} ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="dialog-title" tabIndex={-1}>
      <header className="dialog-header"><div><span className="eyebrow">{titles[panel][1]}</span><h2 id="dialog-title">{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="关闭面板"><X size={21} /></button></header>
      <div className="dialog-content">
        {panel === 'court' && <>
          <div className="dialog-tabs"><button className={courtTab === 'events' ? 'active' : ''} onClick={() => setCourtTab('events')}>待议奏折 <span>{pending.length}</span></button><button className={courtTab === 'council' ? 'active' : ''} onClick={() => { setCourtTab('council'); onEvent(null); }}>内阁大臣</button></div>
          {courtTab === 'events' && !event && <><div className="court-banner"><img src="/images/palace.jpg" alt="晨光中的大宋宫阙" /><div><span>勤政以治国 · 明德以安民</span><h3>天下之事，皆在一念之间。</h3></div></div>
            {pending.length ? pending.map(e => <button key={e.id} className="court-list-item" onClick={() => onEvent(e.id)}><span className={`event-icon ${e.id}`}><ScrollText size={23} /></span><span><strong>{e.title}<em className={`tag tag-${e.id}`}>{e.category}</em></strong><small>{e.subtitle}</small></span><ChevronRight size={17} /></button>) : <div className="empty-state"><Check size={36} /><h3>今日奏折已悉数批复</h3><p>百官各司其职，陛下可稍歇片刻。</p></div>}
          </>}
          {courtTab === 'events' && event && <div className="memorial"><button className="text-button" onClick={() => onEvent(null)}><ArrowLeft size={14} /> 返回奏折</button><span className="memorial-seal">奏</span><span className="eyebrow">{event.source}</span><h3>{event.title}</h3><p>{event.description}</p><div className="memorial-sign">臣诚惶诚恐，顿首顿首。</div><div className="ornament-divider">◆</div>{game.resolvedEvents.includes(event.id) ? <div className="success-note"><Check size={20} /> 圣旨已颁，诸司奉行。<button onClick={() => onEvent(null)}>审阅其他奏折 <ArrowRight size={15} /></button></div> : <div className="decision-list">{event.choices.map(choice => <button disabled={busy} key={choice.id} onClick={() => onAction({ type: 'resolve', eventId: event.id, choiceId: choice.id })}><span><strong>{choice.text}</strong><small>{choice.detail}</small></span><ChevronRight size={18} /></button>)}</div>}</div>}
          {courtTab === 'council' && <><p className="section-description">宰相辅弼天子，总领百官。任命消耗 300 银两，增加 30 威望。</p>{[{ name: '王安石', role: '改革派 · 经世致用', skill: 96, quote: '天变不足畏，祖宗不足法。' }, { name: '司马光', role: '稳健派 · 守正持重', skill: 94, quote: '才者，德之资也；德者，才之帅也。' }, { name: '富弼', role: '务实派 · 外交谋略', skill: 91, quote: '治国之道，务在安民。' }].map(m => <div className="minister-row" key={m.name}><div className="minister-avatar">{m.name.slice(0, 1)}</div><div><h3>{m.name} <span className="tag">治政 {m.skill}</span></h3><p>{m.role}</p><small>“{m.quote}”</small></div><button className="outline-button" disabled={busy || game.council === m.name} onClick={() => onAction({ type: 'council', name: m.name })}>{game.council === m.name ? '现任宰相' : '诏命拜相'}</button></div>)}</>}
        </>}

        {panel === 'dynasty' && <>
          <div className="dynasty-profile"><img src="/images/emperor.png" alt="宋神宗赵顼" /><div><span className="eyebrow">赵氏皇族 · 第六代天子</span><h3>赵 顼 <span>宋神宗</span></h3><p>十九岁 · 壮志凌云 · 在位元年</p><div className="trait-list"><span><Crown size={15} /> 雄才大略</span><span><BookOpen size={15} /> 勤学好问</span><span><Heart size={15} /> 宽仁待人</span></div><div className="ruler-skills"><span>治政 <b>86</b></span><span>军事 <b>74</b></span><span>外交 <b>81</b></span><span>谋略 <b>89</b></span></div></div></div>
          <div className="section-heading"><h3>宗室亲眷</h3><span>赐金帛：400 银两 / 威望 +40</span></div>
          {[{ name: '高太后', role: '皇太后 · 皇室长辈', icon: '高', trait: '贤明持重' }, { name: '向皇后', role: '中宫皇后 · 结发同心', icon: '向', trait: '温良恭俭' }, { name: '赵颢', role: '皇弟 · 东阳郡王', icon: '赵', trait: '文武兼备' }].map(p => <div className="family-row" key={p.name}><div className="family-avatar">{p.icon}</div><div><h3>{p.name}</h3><p>{p.role}</p><span>{p.trait}</span></div><button disabled={busy || game.rewards.includes(p.name)} className="outline-button" onClick={() => onAction({ type: 'reward', name: p.name })}>{game.rewards.includes(p.name) ? '已赐封赏' : '赐予封赏'}</button></div>)}
          <p className="footnote">人物与年代采用架空演绎，以帝王养成与策略体验为主。</p>
        </>}

        {panel === 'military' && <>
          <div className="stat-banner"><Swords size={33} /><div><span>大宋可用兵力</span><strong>{format(game.troops)} <small>人</small></strong></div><span className="status-pill">军心稳固</span></div>
          <div className="section-heading"><h3>天下兵马</h3><span>常备军 · 三路防区</span></div>
          {[{ name: '西北禁军', place: '永兴军路 · 西北边防', count: 12800 }, { name: '京畿禁军', place: '京畿路 · 皇都宿卫', count: 32600 }, { name: '各路厢军', place: '诸路州府 · 驻守屯田', count: 41000 }].map(a => <div className="army-row" key={a.name}><span className="small-banner">宋</span><div><h3>{a.name}</h3><p>{a.place}</p></div><strong>{format(a.count)}</strong><span className="muted-label">驻防中</span></div>)}
          {game.orders.map(o => <div className="recruit-order" key={o.id}><div><Flag size={17} /><strong>{o.name}</strong><span>3,000 人</span><em>{o.status === 'arrived' ? '已完成集结' : `集结中 · 还需 ${Math.max(0, o.arrivalDay - game.day)} 日`}</em></div><div className="progress-track"><span style={{ width: `${o.status === 'arrived' ? 100 : Math.max(5, (game.day - o.startDay) / 3 * 100)}%` }} /></div></div>)}
          <div className="recruit-box"><div><h3>征募新军</h3><p>3,000 名禁军 · 1,200 银两 · 5,000 粮草 · 3 日集结</p></div><div className="recruit-actions"><select aria-label="新军集结地点" value={recruitProvince} onChange={e => setRecruitProvince(e.target.value)}>{PROVINCES.filter(p => p.realm === '大宋').map(p => <option key={p.id} value={p.id}>{p.capital} · {p.name}</option>)}</select><button className="gold-button" disabled={busy} onClick={() => onAction({ type: 'recruit', provinceId: recruitProvince })}><Swords size={16} /> 下诏征募</button></div>{game.paused && <p className="inline-hint">时间已暂停。<button onClick={() => onAction({ type: 'pause' })} disabled={busy}>继续时间</button>以推进新军集结。</p>}</div>
        </>}

        {panel === 'diplomacy' && <><p className="section-description">远交近睦，慎兵修好。遣使可提升 20 点关系；关系达到 30 即可开通互市。</p>{[{ id: 'liao', name: '大辽', letter: '辽', leader: '耶律洪基', desc: '北境强邻 · 澶渊盟约' }, { id: 'xia', name: '西夏', letter: '夏', leader: '李谅祚', desc: '西北边邦 · 边境摩擦' }, { id: 'dali', name: '大理', letter: '理', leader: '段思廉', desc: '西南友邦 · 茶马之交' }, { id: 'goryeo', name: '高丽', letter: '丽', leader: '王徽', desc: '东海之邻 · 文书往来' }].map(n => <div className="nation-row" key={n.id}><div className={`nation-banner nation-${n.id}`}>{n.letter}</div><div className="nation-info"><h3>{n.name}<small>{n.leader}</small></h3><p>{n.desc}</p><div className="relation-line"><span style={{ color: game.relations[n.id] >= 30 ? '#91b39e' : '#c68474' }}>{game.relations[n.id] >= 70 ? '友好' : game.relations[n.id] >= 30 ? '和睦' : game.relations[n.id] >= 0 ? '中立' : '紧张'} {game.relations[n.id] > 0 ? '+' : ''}{game.relations[n.id]}</span><div className="progress-track"><span style={{ width: `${(game.relations[n.id] + 100) / 2}%` }} /></div></div></div><div className="nation-actions"><button disabled={busy || game.relations[n.id] >= 100} className="outline-button" onClick={() => onAction({ type: 'diplomacy', realmId: n.id, mode: 'envoy' })}>遣使修好 <small>400 银</small></button><button disabled={busy || game.tradePartners.includes(n.id) || game.relations[n.id] < 30} className="text-button" onClick={() => onAction({ type: 'diplomacy', realmId: n.id, mode: 'trade' })}>{game.tradePartners.includes(n.id) ? <><Check size={13} /> 互市已开通</> : '开通互市 · 800 银'}</button></div></div>)}</>}

        {panel === 'treasury' && <>
          <div className="treasury-stats"><div><Coins /><span>国库银两</span><strong>{format(game.gold)}</strong><small>每月 +{format(game.monthlyIncome)}</small></div><div><Wheat /><span>天下粮储</span><strong>{format(game.grain)}</strong><small>每月 +{format(game.monthlyGrain)}</small></div></div>
          <div className="section-heading"><h3>诸路赋税</h3><span>主要州府月度税收</span></div><div className="income-bars">{PROVINCES.filter(p => p.realm === '大宋').slice(0, 6).map(p => <div key={p.id}><span>{p.name}</span><div><i style={{ width: `${(p.income + (game.developments[p.id] ?? 0) * 40) / 600 * 100}%` }} /></div><b>{p.income + (game.developments[p.id] ?? 0) * 40}</b></div>)}</div>
          <div className="tax-box"><div><h3>天下田赋 <strong>{game.taxRate}%</strong></h3><p>每上调 1 个百分点，月入 +100，民心 −3；减赋则相反。</p></div><div><button disabled={busy || game.taxRate <= 5} className="outline-button" onClick={() => onAction({ type: 'tax', delta: -1 })}>轻徭薄赋</button><button disabled={busy || game.taxRate >= 15} className="outline-button" onClick={() => onAction({ type: 'tax', delta: 1 })}>增加田赋</button></div></div>
          <div className="info-note"><Leaf size={17} /> 当前民心 {game.stability} / 100。取之有度，用之有节，方能国富民安。</div>
        </>}

        {panel === 'province' && <>
          <div className="province-banner"><Landmark size={38} /><div><span className="eyebrow">{province.realm} · {province.terrain}</span><h3>{province.capital}</h3></div><span className="tag">{province.id === 'kaifeng' ? '帝国首都' : province.realm === '大宋' ? '皇室领地' : '外国领土'}</span></div><p className="province-description">{province.description}</p>
          <div className="province-detail-stats"><div><Users size={18} /><span>治下人口</span><strong>{province.population}<small> 万</small></strong></div><div><Coins size={18} /><span>每月赋税</span><strong>{province.income + (game.developments[province.id] ?? 0) * 40}<small> 银</small></strong></div><div><Shield size={18} /><span>驻守兵力</span><strong>{format(province.troops)}<small> 人</small></strong></div></div>
          {province.realm === '大宋' ? <><div className="section-heading"><h3>领地建设</h3><span>民生为本，仓廪为基</span></div><div className="building-row"><span className="building-icon"><Sprout size={30} /></span><div><h3>农田与水利 <em>等级 {game.developments[province.id] ?? 0} / 3</em></h3><p>每级月入 +40 · 粮草 +300 · 民心 +1</p></div><button className="gold-button" disabled={busy || (game.developments[province.id] ?? 0) >= 3} onClick={() => onAction({ type: 'develop', provinceId: province.id })}>{(game.developments[province.id] ?? 0) >= 3 ? '建设已完成' : `扩建 · ${600 + (game.developments[province.id] ?? 0) * 200} 银`}</button></div><button className="full-width-button outline-button" disabled={busy} onClick={() => onAction({ type: 'recruit', provinceId: province.id })}><Swords size={16} /> 在此征募 3,000 名禁军 <span>1,200 银 · 5,000 粮</span></button></> : <div className="info-note"><Flag size={18} /> 此地不属于大宋。请于“四方来朝”中处理邦国关系。</div>}
        </>}

        {panel === 'chronicle' && <><div className="section-heading"><h3>史官秉笔，记述天子起居。</h3><button className="text-button" onClick={exportSave}><Download size={14} /> 导出存档</button></div><div className="chronicle-list">{game.chronicle.map(item => { const d = gameDate(item.day); return <article key={item.id}><div className="chronicle-dot" /><time>{d.year} 年 {d.month} 月 {d.day} 日</time><h3>{item.title}</h3><p>{item.text}</p></article>; })}</div><div className="info-note"><Check size={16} /> 每次诏令均自动保存至当前浏览器对应的独立云端存档。</div></>}

        {panel === 'settings' && <><div className="settings-row"><div><h3>三维地形</h3><p>依据真实高程显示山川起伏，双指拖动可调整视角。</p></div><button className={`switch ${props.is3D ? 'on' : ''}`} role="switch" aria-checked={props.is3D} aria-label="三维地形" onClick={() => props.setIs3D(!props.is3D)}><span /></button></div><div className="settings-row"><div><h3>军队标记</h3><p>在舆图中显示驻军与边境军情。</p></div><button className={`switch ${props.showArmies ? 'on' : ''}`} role="switch" aria-checked={props.showArmies} aria-label="军队标记" onClick={() => props.setShowArmies(!props.showArmies)}><span /></button></div><div className="settings-row"><div><h3>宫廷音效</h3><p>下达诏令时播放轻柔的钟磬声。</p></div><button className={`switch ${props.sound ? 'on' : ''}`} role="switch" aria-checked={props.sound} aria-label="宫廷音效" onClick={() => props.setSound(!props.sound)}><span /></button></div><div className="settings-row"><div><h3>保存山河</h3><p>进度自动保存，也可随时手动存档。</p></div><button disabled={busy} className="outline-button" onClick={() => onAction({ type: 'save' })}>立即保存</button></div><div className="reset-section"><div><h3>重启新朝</h3><p>这会清空本次存档，重新从开局开始。</p></div>{confirmReset ? <div className="reset-confirm"><span>确定放弃当前进度？</span><button className="danger-button" disabled={busy} onClick={async () => { if (await onAction({ type: 'reset' })) onClose(); }}>确认重启</button><button className="text-button" onClick={() => setConfirmReset(false)}>取消</button></div> : <button className="text-button danger-text" onClick={() => setConfirmReset(true)}>开启新朝</button>}</div></>}

        {panel === 'help' && <><div className="help-intro"><Crown size={36} /><h3>执掌日月，御览山河。</h3><p>这是一场实时推进的帝王策略旅程。暂停时筹谋，继续后见证山河变迁。</p></div><div className="help-grid"><article><ScrollText size={23} /><h3>勤理朝政</h3><p>批阅奏折，权衡国库、民心与威望。你的每个选择都会写入起居注。</p></article><article><Swords size={23} /><h3>经略四方</h3><p>征募军队、发展州府、遣使通商，逐步积蓄大宋的实力。</p></article></div><div className="keyboard-guide"><h3>御览舆图</h3><p><span>拖动 / 单指滑动</span>移动地图</p><p><span>滚轮 / 双指捏合</span>缩放地图</p><p><span>右键拖动 / 双指拖动</span>旋转与倾斜</p><p><kbd>空格</kbd>暂停 / 继续时间</p><p><kbd>/</kbd>搜索城池</p><p><kbd>Esc</kbd>关闭面板</p></div><div className="map-disclaimer"><strong>关于地理与历史</strong><p>地图采用真实地球经纬度、海岸线及高程，比例尺随视图缩放；真实尺度不等于每一平方米均独立建模。远景使用地形地图，近景切换卫星影像。游戏疆域基于现代省界作策略化抽象，人物和年代亦含架空设定，并非历史考据复原。</p><small>地理数据：Natural Earth、DataV · 底图：Esri / US National Park Service / Earthstar Geographics · 高程：Mapzen / AWS Open Data · 地图引擎：MapLibre GL JS</small></div></>}
      </div>
      <footer className="dialog-footer"><span className="tiny-diamond">◆</span> 天 命 山 河 <span className="tiny-diamond">◆</span></footer>
    </section>
  </div>;
}
