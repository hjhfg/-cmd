'use client';

import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as maplibregl from 'maplibre-gl';
import { PROVINCES, type ArmyOrder, type Province } from '@/lib/game';
import type { FeatureCollection } from 'geojson';

export type MapMode = 'political' | 'terrain' | 'diplomacy';
export type MapHandle = { zoom: (delta: number) => void; reset: () => void; globe: () => void; flyTo: (p: Province) => void; north: () => void };
type Props = { mode: MapMode; is3D: boolean; selectedId: string | null; onSelect: (p: Province) => void; showArmies: boolean; orders: ArmyOrder[] };

const castle = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 21h18M5 21V10h14v11M3 10l9-5 9 5M7 5V3m10 2V3M9 21v-6h6v6M12 5V1"/><path d="M2 11h20M7 12v3m10-3v3"/></svg>';
const banner = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M5 22V2m0 1h14l-3 5 3 5H5"/></svg>';
const realmLabels = [
  { title: '大 宋', english: 'THE SONG DYNASTY', pos: [111.6, 29.6], className: 'realm-song' },
  { title: '大 辽', english: 'LIAO DYNASTY', pos: [117.1, 44.5], className: 'realm-liao' },
  { title: '西 夏', english: 'WESTERN XIA', pos: [102, 39.2], className: 'realm-xia' },
  { title: '吐 蕃 诸 部', english: 'TIBETAN KINGDOMS', pos: [91, 31.5], className: 'realm-tibet' },
  { title: '大 理', english: 'DALI KINGDOM', pos: [100, 24], className: 'realm-dali' },
  { title: '高 丽', english: 'GORYEO', pos: [128.1, 39.2], className: 'realm-goryeo' },
  { title: '东 海', english: '', pos: [127, 27.5], className: 'realm-sea' },
  { title: '漠 北', english: 'THE NORTHERN STEPPE', pos: [104.5, 48], className: 'realm-steppe' },
];
const provinceToCode: Record<string, number> = { kaifeng: 410000, luoyang: 410000, changan: 610000, chengdu: 510000, jiangning: 320000, linan: 330000, daming: 130000, guangzhou: 440000, xingqing: 640000, yanjing: 110000, dali: 530000 };

const StrategyMap = forwardRef<MapHandle, Props>(function StrategyMap({ mode, is3D, selectedId, onSelect, showArmies, orders }, ref) {
  const container = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const selectRef = useRef(onSelect);
  const markersRef = useRef<maplibregl.Marker[]>([]);
  const armyMarkersRef = useRef<maplibregl.Marker[]>([]);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  selectRef.current = onSelect;

  useImperativeHandle(ref, () => ({
    zoom: delta => mapRef.current?.zoomTo((mapRef.current?.getZoom() ?? 4) + delta, { duration: 500 }),
    reset: () => mapRef.current?.flyTo({ center: [109.7, 33.7], zoom: window.innerWidth < 700 ? 4 : 4.35, pitch: is3D ? 28 : 0, bearing: -5, duration: 1500 }),
    globe: () => mapRef.current?.flyTo({ center: [105, 30], zoom: window.innerWidth < 700 ? 0.8 : 1.55, pitch: 0, bearing: 0, duration: 2400 }),
    flyTo: p => { mapRef.current?.flyTo({ center: p.coord, zoom: Math.max(5.2, mapRef.current.getZoom()), duration: 1300 }); selectRef.current(p); },
    north: () => mapRef.current?.easeTo({ bearing: 0, duration: 700 }),
  }), [is3D]);

  useEffect(() => {
    if (!container.current) return;
    let map: maplibregl.Map;
    let destroyed = false;
    try {
      maplibregl.setWorkerUrl('/maplibre/maplibre-gl-worker.mjs');
      maplibregl.setWorkerCount(2);
      map = new maplibregl.Map({
        container: container.current,
        center: [109.7, 33.7], zoom: window.innerWidth < 700 ? 4 : 4.35,
        pitch: 28, bearing: -5, minZoom: 0.4, maxZoom: 17, maxPitch: 75,
        attributionControl: false,
        canvasContextAttributes: { antialias: true },
        style: {
          version: 8,
          projection: { type: 'globe' },
          sources: {
            physical: { type: 'raster', tiles: [`${window.location.origin}/api/tiles/{z}/{x}/{y}.jpg`], tileSize: 256, maxzoom: 8, attribution: 'Esri · US National Park Service' },
            satellite: { type: 'raster', tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'], tileSize: 256, minzoom: 7, maxzoom: 18, attribution: 'Esri · Earthstar Geographics' },
            china: { type: 'geojson', data: '/maps/china.json' },
            countries: { type: 'geojson', data: '/maps/countries.json' },
            elevation: { type: 'raster-dem', tiles: ['https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png'], tileSize: 256, encoding: 'terrarium', maxzoom: 14, attribution: 'Mapzen · AWS Open Data' },
          },
          layers: [
            { id: 'background', type: 'background', paint: { 'background-color': '#263c3c' } },
            { id: 'physical', type: 'raster', source: 'physical', paint: { 'raster-saturation': 0.05, 'raster-brightness-max': 0.92, 'raster-brightness-min': 0.04, 'raster-contrast': 0.18, 'raster-hue-rotate': -8, 'raster-fade-duration': 200 } },
            { id: 'satellite', type: 'raster', source: 'satellite', minzoom: 7, paint: { 'raster-saturation': -0.15, 'raster-brightness-max': 0.9, 'raster-opacity': ['interpolate', ['linear'], ['zoom'], 7, 0, 8, 1] } },
            { id: 'world-realms', type: 'fill', source: 'countries', filter: ['!=', ['get', 'ADMIN'], 'China'], paint: { 'fill-color': ['match', ['get', 'ADMIN'], 'Mongolia', '#806e57', 'North Korea', '#64756b', 'South Korea', '#64756b', 'Japan', '#666b55', 'Vietnam', '#5b7361', '#6f7060'], 'fill-opacity': 0.24 } },
            { id: 'province-fill', type: 'fill', source: 'china', paint: { 'fill-color': ['match', ['get', 'adcode'], [110000, 120000, 130000, 150000, 210000, 220000, 230000], '#94594f', [620000, 640000], '#ad9566', [540000, 630000], '#7e8373', 650000, '#b39a74', 530000, '#5d8069', '#b5a476'], 'fill-opacity': 0.3 } },
            { id: 'province-boundaries-shadow', type: 'line', source: 'china', paint: { 'line-color': '#343729', 'line-width': 2.4, 'line-opacity': 0.42 } },
            { id: 'province-boundaries', type: 'line', source: 'china', paint: { 'line-color': '#2b2a1c', 'line-width': 0.8, 'line-opacity': 0.55 } },
            { id: 'song-border-glow', type: 'line', source: 'china', filter: ['!', ['in', ['get', 'adcode'], ['literal', [110000, 120000, 130000, 150000, 210000, 220000, 230000, 620000, 640000, 540000, 630000, 650000, 530000, 710000, 810000, 820000]]]], paint: { 'line-color': '#c0262c', 'line-width': 5, 'line-opacity': 0.35, 'line-blur': 3 } },
            { id: 'song-border', type: 'line', source: 'china', filter: ['!', ['in', ['get', 'adcode'], ['literal', [110000, 120000, 130000, 150000, 210000, 220000, 230000, 620000, 640000, 540000, 630000, 650000, 530000, 710000, 810000, 820000]]]], paint: { 'line-color': '#d4363a', 'line-width': 1.6, 'line-opacity': 0.9 } },
            { id: 'province-selected-fill', type: 'fill', source: 'china', filter: ['==', ['get', 'adcode'], 410000], paint: { 'fill-color': '#d1b16a', 'fill-opacity': 0.2 } },
            { id: 'province-selected-line', type: 'line', source: 'china', filter: ['==', ['get', 'adcode'], 410000], paint: { 'line-color': '#e0c582', 'line-width': 1.8, 'line-opacity': 0.9 } },
          ],
          sky: { 'sky-color': '#101c1b', 'horizon-color': '#677466', 'fog-color': '#34433a', 'sky-horizon-blend': 0.5, 'horizon-fog-blend': 0.8, 'fog-ground-blend': 0.8 },
        },
      });
      mapRef.current = map;
    } catch { setFailed(true); return; }

    map.on('load', () => {
      if (destroyed) return;
      setReady(true);
      map.addControl(new maplibregl.ScaleControl({ maxWidth: 95, unit: 'metric' }), 'bottom-left');
      map.setTerrain({ source: 'elevation', exaggeration: 1 });
      realmLabels.forEach(label => {
        const element = document.createElement('div');
        element.className = `realm-label ${label.className}`;
        element.innerHTML = `<span>${label.title}</span><small>${label.english}</small>`;
        const marker = new maplibregl.Marker({ element, anchor: 'center' }).setLngLat(label.pos as [number, number]).addTo(map);
        markersRef.current.push(marker);
      });
      PROVINCES.forEach(province => {
        const element = document.createElement('button');
        element.type = 'button';
        element.className = `city-marker ${province.id === 'kaifeng' ? 'capital-marker' : ''}`;
        element.dataset.city = province.id;
        element.setAttribute('aria-label', `${province.name} ${province.capital}`);
        element.innerHTML = `${province.id === 'kaifeng' ? '<span class="capital-banner">宋</span>' : ''}<span class="city-symbol">${castle}</span><span class="city-label">${province.capital}${province.id === 'kaifeng' ? '<small>皇都</small>' : ''}</span>`;
        element.addEventListener('click', event => { event.stopPropagation(); selectRef.current(province); });
        markersRef.current.push(new maplibregl.Marker({ element, anchor: 'bottom' }).setLngLat(province.coord).addTo(map));
      });
      const armyPositions: { name: string; count: string; pos: [number, number]; enemy?: boolean }[] = [
        { name: '宋', count: '12,800', pos: [109.1, 36.6] },
        { name: '宋', count: '8,600', pos: [115.4, 31.9] },
        { name: '夏', count: '18,200', pos: [105.1, 37.7], enemy: true },
      ];
      armyPositions.forEach(army => {
        const element = document.createElement('button');
        element.className = `army-marker ${army.enemy ? 'army-enemy' : ''}`;
        element.title = army.enemy ? '西夏铁骑 · 18,200 人' : '大宋禁军 · 驻防中';
        element.innerHTML = `<span class="army-flag">${army.name}</span><span class="army-count">${banner}${army.count}</span>`;
        element.addEventListener('click', e => { e.stopPropagation(); selectRef.current(PROVINCES.find(p => p.id === (army.enemy ? 'xingqing' : 'changan'))!); });
        const marker = new maplibregl.Marker({ element, anchor: 'bottom' }).setLngLat(army.pos).addTo(map);
        armyMarkersRef.current.push(marker);
      });
      const route: FeatureCollection = { type: 'FeatureCollection', features: [{ type: 'Feature', properties: {}, geometry: { type: 'LineString', coordinates: [[114.31,34.8],[113.6,35.25],[112.3,35.8],[111,36.4],[109.1,36.6]] } }] };
      map.addSource('march-route', { type: 'geojson', data: route });
      map.addLayer({ id: 'march-route', type: 'line', source: 'march-route', paint: { 'line-color': '#e8c983', 'line-width': 1.4, 'line-dasharray': [2, 4], 'line-opacity': 0.7 } });
      map.on('click', 'province-fill', event => {
        const code = Number(event.features?.[0].properties.adcode);
        const province = PROVINCES.find(p => provinceToCode[p.id] === code);
        if (province) selectRef.current(province);
      });
      map.on('mouseenter', 'province-fill', () => { map.getCanvas().style.cursor = 'pointer'; });
      map.on('mouseleave', 'province-fill', () => { map.getCanvas().style.cursor = ''; });
      const updateMarkerVisibility = () => {
        const z = map.getZoom();
        markersRef.current.forEach(marker => {
          const el = marker.getElement();
          const isRealm = el.classList.contains('realm-label');
          const hidden = isRealm ? z < 2.5 || z > 6.2 : z < 2.8;
          el.style.visibility = hidden ? 'hidden' : 'visible';
          el.style.pointerEvents = hidden || isRealm ? 'none' : '';
        });
        armyMarkersRef.current.forEach(marker => { marker.getElement().style.visibility = z < 3 ? 'hidden' : 'visible'; });
      };
      updateMarkerVisibility();
      map.on('zoom', updateMarkerVisibility);
    });
    map.on('error', e => {
      const message = String(e.error?.message);
      if (/WebGL|Worker.*failed/i.test(message)) setFailed(true);
    });
    const resize = new ResizeObserver(() => map.resize());
    resize.observe(container.current);
    return () => { destroyed = true; resize.disconnect(); markersRef.current = []; armyMarkersRef.current = []; map.remove(); mapRef.current = null; };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!ready || !map) return;
    map.setPaintProperty('province-fill', 'fill-opacity', mode === 'terrain' ? 0.04 : mode === 'diplomacy' ? 0.55 : 0.36);
    map.setPaintProperty('province-boundaries', 'line-opacity', mode === 'terrain' ? 0.2 : 0.58);
    map.setPaintProperty('world-realms', 'fill-opacity', mode === 'terrain' ? 0 : 0.24);
    map.setPaintProperty('province-fill', 'fill-color', mode === 'diplomacy'
      ? ['match', ['get', 'adcode'], [620000, 640000], '#ae5549', [110000, 120000, 130000, 150000, 210000, 220000, 230000], '#77787e', 530000, '#4b8d73', '#ab9e65']
      : ['match', ['get', 'adcode'], [110000, 120000, 130000, 150000, 210000, 220000, 230000], '#94594f', [620000, 640000], '#ad9566', [540000, 630000], '#7e8373', 650000, '#b39a74', 530000, '#5d8069', '#b5a476']);
  }, [mode, ready]);

  useEffect(() => {
    const map = mapRef.current;
    if (!ready || !map) return;
    map.setTerrain(is3D ? { source: 'elevation', exaggeration: 1 } : null);
    map.easeTo({ pitch: is3D ? 28 : 0, duration: 800 });
  }, [is3D, ready]);

  useEffect(() => {
    if (!ready || !mapRef.current) return;
    const code = selectedId ? (provinceToCode[selectedId] ?? 0) : 0;
    mapRef.current.setFilter('province-selected-fill', ['==', ['get', 'adcode'], code]);
    mapRef.current.setFilter('province-selected-line', ['==', ['get', 'adcode'], code]);
    markersRef.current.forEach(marker => marker.getElement().classList.toggle('city-selected', marker.getElement().dataset.city === selectedId));
  }, [selectedId, ready]);

  useEffect(() => {
    armyMarkersRef.current.forEach(marker => { marker.getElement().style.display = showArmies ? '' : 'none'; });
  }, [showArmies, ready]);

  useEffect(() => {
    const map = mapRef.current;
    if (!ready || !map) return;
    const source = map.getSource('march-route') as maplibregl.GeoJSONSource | undefined;
    if (!source || !orders.length) return;
    source.setData({ type: 'FeatureCollection', features: orders.filter(o => o.status === 'marching').map(o => {
      const p = PROVINCES.find(p => p.id === o.destination) ?? PROVINCES[0];
      return { type: 'Feature' as const, properties: {}, geometry: { type: 'LineString' as const, coordinates: [[114.31,34.8], [p.coord[0] - 0.5, p.coord[1] - 0.3], p.coord] } };
    }) });
  }, [orders, ready]);

  return <div className={`strategy-map ${ready ? 'map-loaded' : ''}`}>
    <div className="map-fallback" />
    <div ref={container} className={`map-canvas ${ready ? 'is-ready' : ''}`} aria-label="可拖动缩放的三维地球战略地图" />
    <div className="map-vignette" />
    {!ready && !failed && <div className="map-loading"><span /> 正在铺展万里山河…</div>}
    {failed && <div className="map-offline"><span>此设备无法启用 WebGL，已切换静态舆图。</span><button onClick={() => selectRef.current(PROVINCES[0])}>查看皇都</button></div>}
  </div>;
});

export default StrategyMap;
