'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import dynamic from 'next/dynamic';
import { ArrowUpRight, BookOpen, Castle, CircleHelp, CloudCheck, CloudOff, Coins, Crown, Flag, Globe2, Handshake, Landmark, LoaderCircle, MapPinned, Minus, Mountain, Pause, Play, Plus, Scale, ScrollText, Search, Settings, Shield, Swords, Users, Wheat, X } from 'lucide-react';
import { COURT_EVENTS, PROVINCES, createGame, gameDate, type GameAction, type GameState, type Province } from '@/lib/game';
import type { MapHandle, MapMode } from './strategy-map';
import GamePanels, { type Panel } from './game-panels';

const StrategyMap = dynamic(() => import('./strategy-map'), { ssr: false, loading: () => <div className="map-fallback" /> });
const number = (n: number) => n.toLocaleString('en-US');
const STRIP = [
  { id: 'court', label: '朝政', icon: Landmark }, { id: 'dynasty', label: '宗族', icon: Crown },
  { id: 'military', label: '军事', icon: Swords }, { id: 'diplomacy', label: '外交', icon: Handshake },
  { id: 'treasury', label: '府库', icon: Coins }, { id: 'chronicle', label: '史记', icon: BookOpen },
] as const;
const kindIcon = { court: ScrollText, military: Swords, realm: Wheat, diplomacy: Handshake, system: Crown };

export default function ImperialGame() {
  const [game, setGame] = useState<GameState>(createGame);
  const [panel, setPanel] = useState<Panel | null>(null);
  const [selected, setSelected] = useState<Province | null>(null);
  const [eventId, setEventId] = useState<string | null>(null);
  const [mode, setMode] = useState<MapMode>('political');
  const [is3D, setIs3D] = useState(true);
  const [showArmies, setShowArmies] = useState(true);
  const [sound, setSound] = useState(false);
  const [busy, setBusy] = useState(false);
  const [connected, setConnected] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [feedOpen, setFeedOpen] = useState(true);
  const [query, setQuery] = useState('');
  const [toast, setToast] = useState<{ text: string; error: boolean } | null>(null);
  const mapRef = useRef<MapHandle>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const busyRef = useRef(false);
  const initialized = useRef(false);
  const sequence = useRef(0);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const date = gameDate(game.day);
  const pending = COURT_EVENTS.filter(e => !game.resolvedEvents.includes(e.id));
  const marching = game.orders.filter(o => o.status === 'marching');
  const results = PROVINCES.filter(p => `${p.name}${p.capital}${p.realm}`.includes(query.trim()));

  const notify = useCallback((text: string, error = false) => {
    setToast({ text, error });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 4000);
  }, []);

  const loadGame = useCallback(async () => {
    if (busyRef.current) return;
    const request = ++sequence.current;
    try {
      const response = await fetch('/api/game', { cache: 'no-store' });
      if (!response.ok) throw new Error('load');
      const data = await response.json();
      if (request !== sequence.current) return;
      setGame(data.state); setConnected(true); initialized.current = true;
    } catch { setConnected(false); }
  }, []);

  useEffect(() => {
    loadGame();
    const interval = setInterval(() => { if (!document.hidden) loadGame(); }, 4000);
    return () => { clearInterval(interval); if (toastTimer.current) clearTimeout(toastTimer.current); };
  }, [loadGame]);

  useEffect(() => {
    try { const p = JSON.parse(localStorage.getItem('tianming-preferences') ?? 'null'); if (p) { setSound(Boolean(p.sound)); setIs3D(p.is3D !== false); setShowArmies(p.showArmies !== false); } } catch {}
  }, []);
  useEffect(() => { localStorage.setItem('tianming-preferences', JSON.stringify({ sound, is3D, showArmies })); }, [sound, is3D, showArmies]);

  const act = useCallback(async (action: GameAction): Promise<boolean> => {
    if (busyRef.current) return false;
    if (!initialized.current) { notify('存档尚未连接，正在重试…', true); await loadGame(); return false; }
    busyRef.current = true; setBusy(true); ++sequence.current;
    try {
      const response = await fetch('/api/game', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(action) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? '诏令未能送达。');
      setGame(data.state); setConnected(true); notify(data.message); return true;
    } catch (error) { notify(error instanceof Error ? error.message : '网络暂不可用', true); return false; }
    finally { busyRef.current = false; setBusy(false); }
  }, [loadGame, notify]);

  const closePanel = useCallback(() => setPanel(null), []);
  const openPanel = (next: Panel, event: string | null = null) => { setPanel(next); setEventId(event); setSearchOpen(false); };
  const chooseProvince = useCallback((p: Province) => setSelected(p), []);
  const searchProvince = (p: Province) => { setSelected(p); mapRef.current?.flyTo(p); setSearchOpen(false); setQuery(''); };

  useEffect(() => {
    const keyboard = (event: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((event.target as HTMLElement).tagName)) return;
      if (event.code === 'Space' && !panel) { event.preventDefault(); act({ type: 'pause' }); }
      if (event.key === '/' && !panel) { event.preventDefault(); setSearchOpen(true); }
      if (event.key === 'Escape') setSearchOpen(false);
    };
    window.addEventListener('keydown', keyboard);
    return () => window.removeEventListener('keydown', keyboard);
  }, [act, panel]);
  useEffect(() => { if (searchOpen) setTimeout(() => searchRef.current?.focus(), 50); }, [searchOpen]);

  const feed = game.chronicle.slice(0, 5);

  return <main className="ck-shell">
    <section className="ck-stage" aria-label="天下舆图">
      <StrategyMap ref={mapRef} mode={mode} is3D={is3D} selectedId={selected?.id ?? null} onSelect={chooseProvince} showArmies={showArmies} orders={game.orders} />
    </section>

    {/* 顶部：菱形提醒 */}
    <div className="ck-alerts" aria-label="待处理事项">
      {pending.map(e => <button key={e.id} className={`ck-diamond d-${e.id}`} title={`${e.title} · ${e.subtitle}`} aria-label={`奏折：${e.title}`} onClick={() => openPanel('court', e.id)}><span>{e.id === 'flood' ? <Wheat size={17} /> : e.id === 'border' ? <Swords size={17} /> : <ScrollText size={17} />}</span></button>)}
      {marching.map(o => <button key={o.id} className="ck-diamond d-army" title={`${o.name} 集结中`} aria-label={`${o.name}集结中`} onClick={() => openPanel('military')}><span><Flag size={16} /></span></button>)}
      {game.taxRate > 12 && <button className="ck-diamond d-warn" title="赋税过重，民心下降" aria-label="赋税过重" onClick={() => openPanel('treasury')}><span><Scale size={16} /></span></button>}
      <button className="ck-alert-count" title="待议奏折" aria-label={`共${pending.length}件待议`} onClick={() => openPanel('court')}>{pending.length + marching.length}</button>
    </div>
    {game.paused && <button className="ck-paused" onClick={() => act({ type: 'pause' })} aria-label="继续时间（暂停提示）">暂停</button>}

    {/* 右上：资源栏 */}
    <header className="ck-resources">
      <button className="resource" title="国库银两" onClick={() => openPanel('treasury')}><Coins className="gold" size={17} /><span><strong>{number(game.gold)}</strong><small>+{(game.monthlyIncome / 30).toFixed(1)}</small></span></button>
      <button className="resource" title="天下粮储" onClick={() => openPanel('treasury')}><Wheat className="wheat" size={17} /><span><strong>{game.grain >= 10000 ? `${(game.grain / 1000).toFixed(0)}k` : number(game.grain)}</strong><small>+{(game.monthlyGrain / 30).toFixed(1)}</small></span></button>
      <button className="resource" title="皇室威望" onClick={() => openPanel('dynasty')}><Crown className="prestige" size={17} /><span><strong>{number(game.prestige)}</strong><small>+1.0</small></span></button>
      <button className="resource" title="民心" onClick={() => openPanel('treasury')}><Users className="piety" size={17} /><span><strong>{game.stability}</strong><small>/100</small></span></button>
      <button className="resource ck-troops" title="天下兵马" onClick={() => openPanel('military')}><Swords size={16} /><span><strong>{number(game.troops)}</strong></span></button>
      <button className="ck-save" aria-label={connected ? '手动保存游戏' : '重新连接存档'} title={connected ? '已同步 · 点击存档' : '连接中'} onClick={() => connected ? act({ type: 'save' }) : loadGame()}>{busy ? <LoaderCircle className="spin" size={15} /> : connected ? <CloudCheck size={15} /> : <CloudOff size={15} />}</button>
    </header>

    {/* 右侧：图标栏 */}
    <nav className="ck-strip" aria-label="帝国主菜单">
      {STRIP.map(item => { const Icon = item.icon; return <button key={item.id} className={panel === item.id ? 'active' : ''} aria-label={item.label} title={item.label} onClick={() => openPanel(item.id)}><Icon size={18} strokeWidth={1.6} />{item.id === 'court' && pending.length > 0 && <i />}</button>; })}
      <span className="ck-strip-sep" />
      <button aria-label="搜索城池" title="搜索城池 (/)" onClick={() => setSearchOpen(!searchOpen)}><Search size={17} /></button>
      <button aria-label="游戏设置" title="设置" onClick={() => openPanel('settings')}><Settings size={17} /></button>
      <button aria-label="玩法帮助" title="帮助" onClick={() => openPanel('help')}><CircleHelp size={17} /></button>
    </nav>

    {searchOpen && <div className="ck-search"><div className="search-input-wrap"><Search size={16} /><input ref={searchRef} value={query} onChange={e => setQuery(e.target.value)} placeholder="寻访城池、州府…" aria-label="搜索城池名称" /><button aria-label="关闭搜索" onClick={() => setSearchOpen(false)}><X size={15} /></button></div><div className="search-results">{results.length ? results.map(p => <button key={p.id} onClick={() => searchProvince(p)}><Landmark size={16} /><span><strong>{p.capital}</strong><small>{p.name} · {p.realm}</small></span><ArrowUpRight size={14} /></button>) : <p>未寻得此地</p>}</div></div>}

    {/* 左下：君主 */}
    <div className="ck-ruler">
      <button className="ck-portrait" aria-label="查看天子赵顼" title="赵顼 · 大宋天子 · 19岁" onClick={() => openPanel('dynasty')}><img src="/images/emperor.png" alt="天子赵顼" /></button>
      <button className="ck-crest" aria-label="大宋国徽" title="大宋 · 皇帝" onClick={() => { closePanel(); mapRef.current?.reset(); }}><span>宋</span><i><Crown size={11} /></i></button>
      <div className="ck-ruler-buttons">
        <button aria-label="宣政殿奏折" title="朝堂要务" onClick={() => openPanel('court')}><ScrollText size={15} /></button>
        <button aria-label="皇室宗亲" title="宗族" onClick={() => openPanel('dynasty')}><Users size={15} /></button>
        <button aria-label="天下兵马调度" title="征募军队" onClick={() => openPanel('military')}><Shield size={15} /></button>
        <button aria-label="四方邦交" title="外交" onClick={() => openPanel('diplomacy')}><Handshake size={15} /></button>
      </div>
      <div className="ck-health" title={`民心 ${game.stability}`}><span style={{ width: `${game.stability}%` }} /></div>
    </div>

    {/* 选中领地提示 */}
    {selected && <div className="ck-tooltip" role="dialog" aria-label="已选领地">
      <button className="close-province" aria-label="取消选中领地" onClick={() => setSelected(null)}><X size={12} /></button>
      <h2>{selected.name} · {selected.capital}</h2><small>{selected.realm} · {selected.terrain}</small>
      <div className="ck-tip-stats"><span><Users size={12} />{selected.population}万</span><span><Coins size={12} />+{selected.income + (game.developments[selected.id] ?? 0) * 40}</span><span><Shield size={12} />{number(selected.troops)}</span></div>
      <div className="ck-tip-actions"><button onClick={() => openPanel('province')}><Castle size={13} /> 领地</button><button disabled={selected.realm !== '大宋'} onClick={() => openPanel('military')}><Swords size={13} /> 征兵</button></div>
    </div>}

    {/* 右下：事件流 */}
    {feedOpen && <aside className="ck-feed" aria-label="近期事件">
      {feed.map((item, i) => { const Icon = kindIcon[item.kind]; const d = gameDate(item.day); return <button key={item.id} className={i === 0 ? 'first' : ''} onClick={() => openPanel('chronicle')}><Icon size={13} /><span>{item.title}</span><time>{d.month}月{d.day}日</time></button>; })}
      {feed[0] && <div className="ck-feed-detail"><p>{feed[0].text}</p><div><img src="/images/emperor.png" alt="" /><span className="ck-mini-crest">宋</span></div></div>}
      <button className="ck-feed-close" aria-label="收起事件" onClick={() => setFeedOpen(false)}><X size={11} /></button>
    </aside>}
    {!feedOpen && <button className="ck-feed-open" aria-label="展开事件" onClick={() => setFeedOpen(true)}><BookOpen size={14} /></button>}

    {/* 右下：地图模式 + 日期 */}
    <div className="ck-corner">
      <div className="ck-modes" aria-label="地图模式">
        {[{ id: 'political' as const, label: '疆域', icon: Flag }, { id: 'terrain' as const, label: '地形', icon: Mountain }, { id: 'diplomacy' as const, label: '外交', icon: Handshake }].map(m => <button key={m.id} className={mode === m.id ? 'active' : ''} aria-label={`${m.label}地图`} aria-pressed={mode === m.id} title={`${m.label}地图`} onClick={() => setMode(m.id)}><m.icon size={14} /></button>)}
        <button className={is3D ? 'active ck-3d' : 'ck-3d'} aria-label="切换三维地形" aria-pressed={is3D} title="三维地形" onClick={() => setIs3D(!is3D)}>3D</button>
        <button aria-label="全球视图" title="全球视图" onClick={() => mapRef.current?.globe()}><Globe2 size={14} /></button>
        <button aria-label="回到大宋疆域" title="回到大宋" onClick={() => mapRef.current?.reset()}><MapPinned size={14} /></button>
        <button aria-label="放大地图" title="放大" onClick={() => mapRef.current?.zoom(0.7)}><Plus size={14} /></button>
        <button aria-label="缩小地图" title="缩小" onClick={() => mapRef.current?.zoom(-0.7)}><Minus size={14} /></button>
      </div>
      <div className="ck-datebar">
        <button className="ck-play" disabled={busy} onClick={() => act({ type: 'pause' })} aria-label={game.paused ? '继续时间' : '暂停时间'} title="空格">{game.paused ? <Play size={14} fill="currentColor" strokeWidth={0} /> : <Pause size={14} fill="currentColor" strokeWidth={0} />}</button>
        <span className="ck-date">公元{date.year}年{date.month}月{date.day}日</span>
        <div className="ck-speed">{[1, 2, 4].map(s => <button key={s} disabled={busy} className={game.speed >= s ? 'on' : ''} aria-label={`${s}倍速`} aria-pressed={game.speed === s} onClick={() => act({ type: 'speed', value: s })} />)}</div>
        <button className="ck-globe-mini" aria-label="打开全球视野" title="世界地图" onClick={() => mapRef.current?.globe()}><Globe2 size={13} /></button>
      </div>
    </div>

    {toast && <div className={`game-toast ${toast.error ? 'error' : ''}`} role="status"><span>{toast.text}</span><button aria-label="关闭消息" onClick={() => setToast(null)}><X size={14} /></button></div>}
    {panel && <GamePanels key={panel} panel={panel} game={game} province={selected ?? PROVINCES[0]} eventId={eventId} onEvent={setEventId} onClose={closePanel} onAction={act} busy={busy} is3D={is3D} setIs3D={setIs3D} showArmies={showArmies} setShowArmies={setShowArmies} sound={sound} setSound={setSound} />}
  </main>;
}
