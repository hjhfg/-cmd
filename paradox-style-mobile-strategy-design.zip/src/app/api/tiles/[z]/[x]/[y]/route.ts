import { readFile } from 'node:fs/promises';
import path from 'node:path';

export async function GET(_request: Request, { params }: { params: Promise<{ z: string; x: string; y: string }> }) {
  const p = await params;
  const z = Number(p.z), x = Number(p.x), y = Number(p.y.replace('.jpg', ''));
  if (![z,x,y].every(Number.isInteger) || z < 0 || z > 8 || x < 0 || y < 0 || x >= 2 ** z || y >= 2 ** z) return new Response(null, { status: 400 });
  const headers = { 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=604800, immutable' };
  try {
    const data = await readFile(path.join(process.cwd(), 'public', 'maps', 'tiles', String(z), String(x), `${y}.jpg`));
    return new Response(new Uint8Array(data), { headers });
  } catch {
    try {
      const response = await fetch(`https://server.arcgisonline.com/ArcGIS/rest/services/World_Physical_Map/MapServer/tile/${z}/${y}/${x}`, { signal: AbortSignal.timeout(12000), next: { revalidate: 604800 } });
      if (!response.ok) throw new Error('tile unavailable');
      return new Response(await response.arrayBuffer(), { headers });
    } catch { return new Response(null, { status: 503 }); }
  }
}
