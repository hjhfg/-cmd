import { cookies } from 'next/headers';
import { db } from '@/db';
import { imperialGames } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { advanceGame, applyAction, createGame, GameError, type GameAction } from '@/lib/game';
import { randomUUID } from 'node:crypto';

export const dynamic = 'force-dynamic';
const COOKIE = 'tianming-save';

async function session() {
  const jar = await cookies();
  const existing = jar.get(COOKIE)?.value;
  if (existing && /^[0-9a-f-]{36}$/i.test(existing)) {
    const [game] = await db.select().from(imperialGames).where(eq(imperialGames.id, existing));
    if (game) return game.id;
  }
  const id = randomUUID();
  await db.insert(imperialGames).values({ id, state: createGame() });
  jar.set(COOKIE, id, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 365 });
  return id;
}

export async function GET() {
  try {
    const id = await session();
    const state = await db.transaction(async tx => {
      const [row] = await tx.select().from(imperialGames).where(eq(imperialGames.id, id)).for('update');
      const next = advanceGame(row.state);
      await tx.update(imperialGames).set({ state: next, updatedAt: new Date() }).where(eq(imperialGames.id, id));
      return next;
    });
    return Response.json({ state }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    console.error('Game load:', error);
    return Response.json({ error: '暂时无法读取存档，请稍后重试。' }, { status: 503 });
  }
}

export async function POST(request: Request) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== 'object' || !('type' in body) || typeof body.type !== 'string') {
      return Response.json({ error: '诏令格式无效。' }, { status: 400 });
    }
    const id = await session();
    const result = await db.transaction(async tx => {
      const [row] = await tx.select().from(imperialGames).where(eq(imperialGames.id, id)).for('update');
      const result = applyAction(row.state, body as GameAction);
      await tx.update(imperialGames).set({ state: result.state, updatedAt: new Date() }).where(eq(imperialGames.id, id));
      return result;
    });
    return Response.json(result);
  } catch (error) {
    if (error instanceof GameError) return Response.json({ error: error.message }, { status: 400 });
    console.error('Game action:', error);
    return Response.json({ error: '诏令未能送达，请稍后重试。' }, { status: 500 });
  }
}
