import ImperialGame from '@/components/imperial-game';

export default function HomePage() {
  return <ImperialGame />;
}
