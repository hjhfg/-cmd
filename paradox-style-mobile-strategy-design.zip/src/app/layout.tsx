import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import 'maplibre-gl/dist/maplibre-gl.css';
import './globals.css';

export const metadata: Metadata = {
  title: '天命山河 · 皇帝成长计划 II',
  description: '执掌日月，御览山河。宋代背景的实时帝王策略沙盘，真实地球地图、3D 地形、朝政与皇室经营。',
  appleWebApp: { capable: true, statusBarStyle: 'black-translucent', title: '天命山河' },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, maximumScale: 1, themeColor: '#151c1b' };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
