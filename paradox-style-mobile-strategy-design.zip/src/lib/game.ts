export type Province = {
  id: string; name: string; capital: string; realm: string; coord: [number, number];
  population: string; income: number; troops: number; terrain: string; description: string;
};

export const PROVINCES: Province[] = [
  { id: 'kaifeng', name: '京畿路', capital: '开封', realm: '大宋', coord: [114.31, 34.8], population: '124.6', income: 380, troops: 12600, terrain: '平原 · 都城', description: '八荒争凑，万国咸通。汴京地处中原腹地，漕运兴盛，是大宋的政治与商贸中心。' },
  { id: 'luoyang', name: '京西北路', capital: '洛阳', realm: '大宋', coord: [112.45, 34.62], population: '86.2', income: 240, troops: 8400, terrain: '平原 · 古都', description: '河山拱戴，形势甲于天下。西京洛阳田畴广沃，士人云集。' },
  { id: 'changan', name: '永兴军路', capital: '京兆', realm: '大宋', coord: [108.94, 34.34], population: '72.8', income: 210, troops: 14800, terrain: '盆地 · 要塞', description: '关中四塞，沃野千里。永兴军扼守西北门户，是抵御西夏的重要防线。' },
  { id: 'chengdu', name: '成都府路', capital: '成都', realm: '大宋', coord: [104.06, 30.57], population: '108.5', income: 320, troops: 9200, terrain: '盆地 · 粮仓', description: '天府之国，水旱从人。蜀锦与交子流通四方，成都百业繁盛。' },
  { id: 'jiangning', name: '江南东路', capital: '江宁', realm: '大宋', coord: [118.8, 32.06], population: '96.3', income: 290, troops: 6800, terrain: '丘陵 · 商埠', description: '江南佳丽地，金陵帝王州。水路四通八达，商贾往来不绝。' },
  { id: 'linan', name: '两浙路', capital: '杭州', realm: '大宋', coord: [120.15, 30.27], population: '132.4', income: 420, troops: 7600, terrain: '水乡 · 商埠', description: '东南形胜，三吴都会。钱塘自古繁华，丝绸、茶叶与海贸带来丰厚赋税。' },
  { id: 'daming', name: '河北东路', capital: '大名', realm: '大宋', coord: [115.15, 36.28], population: '68.1', income: 180, troops: 16400, terrain: '平原 · 边城', description: '北控燕赵，南通汴梁。大名府肩负边防重任，亦须时刻提防黄河水患。' },
  { id: 'guangzhou', name: '广南东路', capital: '广州', realm: '大宋', coord: [113.26, 23.13], population: '56.8', income: 260, troops: 5200, terrain: '沿海 · 港口', description: '海舶云集，珍货如山。市舶司掌管海外商贸，南海航线连通远方诸国。' },
  { id: 'xingqing', name: '兴庆府', capital: '兴庆', realm: '西夏', coord: [106.23, 38.48], population: '32.6', income: 120, troops: 18200, terrain: '绿洲 · 都城', description: '贺兰山下，塞上江南。西夏铁骑据此雄视河西，宋夏边境局势微妙。' },
  { id: 'yanjing', name: '南京道', capital: '燕京', realm: '大辽', coord: [116.4, 39.9], population: '82.4', income: 280, troops: 24600, terrain: '平原 · 都城', description: '燕云十六州的重镇。辽国在此屯驻精兵，守望与大宋之间的百年盟约。' },
  { id: 'dali', name: '大理国', capital: '大理', realm: '大理', coord: [100.23, 25.59], population: '28.2', income: 110, troops: 6200, terrain: '高原 · 山城', description: '苍山洱海之间，佛寺林立。大理以茶马贸易连接中原与西南诸部。' },
];

export const COURT_EVENTS = [
  { id: 'flood', title: '黄河春汛', category: '紧急', subtitle: '河北东路奏请修筑河堤', source: '河北转运使 · 奏', description: '陛下，近日黄河水位渐涨，大名府沿岸数处堤坝已有渗漏。若不及时修缮，数万顷良田恐将被淹。臣恳请朝廷拨银赈济，征调民夫，加固河防。', choices: [
    { id: 'fund', text: '拨款修堤，以安百姓', detail: '国库 −1,200 · 民心 +8', gold: -1200, stability: 8, prestige: 25 },
    { id: 'local', text: '命地方筹措，酌情减赋', detail: '国库 −400 · 民心 +3', gold: -400, stability: 3, prestige: 5 },
  ] },
  { id: 'border', title: '西夏边境异动', category: '军情', subtitle: '斥候发现贺兰山下兵马集结', source: '枢密院 · 急报', description: '西北边关传来急报：西夏骑兵近来频繁越境侦察，兴庆府亦有大军集结。守将请求增拨军饷，整修城防，以备不测。', choices: [
    { id: 'defend', text: '整饬边军，增援关隘', detail: '国库 −800 · 威望 +60', gold: -800, stability: 2, prestige: 60 },
    { id: 'envoy', text: '遣使问询，暂守边境', detail: '国库 −200 · 威望 +15', gold: -200, stability: 1, prestige: 15 },
  ] },
  { id: 'exam', title: '春闱将至', category: '内政', subtitle: '礼部请定今岁科举章程', source: '礼部尚书 · 奏', description: '春试在即，天下举子齐聚京师。礼部请陛下定夺今岁取士之法：循旧制以诗赋取士，抑或兼考经义策论，选拔通晓治国之才。', choices: [
    { id: 'reform', text: '增试策论，广纳贤才', detail: '国库 −600 · 威望 +100 · 月入 +60', gold: -600, stability: 2, prestige: 100, income: 60 },
    { id: 'tradition', text: '遵循祖制，稳中求贤', detail: '国库 −300 · 威望 +40', gold: -300, stability: 3, prestige: 40 },
  ] },
];

export type Chronicle = { id: string; day: number; title: string; text: string; kind: 'court' | 'military' | 'realm' | 'diplomacy' | 'system' };
export type ArmyOrder = { id: string; name: string; troops: number; destination: string; startDay: number; arrivalDay: number; status: 'marching' | 'arrived' };
export type GameState = {
  version: number; day: number; gold: number; grain: number; prestige: number; troops: number;
  stability: number; monthlyIncome: number; monthlyGrain: number; paused: boolean; speed: number;
  lastTick: number; resolvedEvents: string[]; developments: Record<string, number>; relations: Record<string, number>;
  orders: ArmyOrder[]; chronicle: Chronicle[]; taxRate: number; rewards: string[]; council: string; tradePartners: string[];
};
export type GameAction = { type: string; [key: string]: unknown };

export function createGame(): GameState {
  return { version: 1, day: 0, gold: 24680, grain: 186500, prestige: 1280, troops: 86400,
    stability: 82, monthlyIncome: 1240, monthlyGrain: 3600, paused: true, speed: 1,
    lastTick: Date.now(), resolvedEvents: [], developments: {}, relations: { liao: 65, xia: -35, dali: 80, goryeo: 45 },
    orders: [], taxRate: 10, rewards: [], council: '王安石', tradePartners: [],
    chronicle: [{ id: 'begin', day: 0, title: '新朝启元', text: '陛下御极，百官朝贺。愿以仁心治天下，以雄略定山河。', kind: 'system' }],
  };
}

export function gameDate(day: number) {
  const d = new Date(Date.UTC(1066, 2, 1) + day * 86400000);
  const month = d.getUTCMonth() + 1;
  return { year: d.getUTCFullYear(), month, day: d.getUTCDate(), season: month >= 3 && month <= 5 ? '春' : month >= 6 && month <= 8 ? '夏' : month >= 9 && month <= 11 ? '秋' : '冬' };
}

function log(s: GameState, title: string, text: string, kind: Chronicle['kind']) {
  s.chronicle.unshift({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, day: s.day, title, text, kind });
  s.chronicle = s.chronicle.slice(0, 100);
}

export function advanceGame(state: GameState): GameState {
  const s = structuredClone(state);
  const now = Date.now();
  if (s.paused) { s.lastTick = now; return s; }
  const duration = 10000 / s.speed;
  const days = Math.min(3650, Math.floor((now - s.lastTick) / duration));
  if (days > 0) {
    s.day += days;
    s.gold += Math.round((s.monthlyIncome / 30) * days);
    s.grain += Math.round((s.monthlyGrain / 30) * days);
    s.prestige += days;
    s.lastTick = now - ((now - s.lastTick) % duration);
    s.orders.forEach(order => {
      if (order.status === 'marching' && s.day >= order.arrivalDay) {
        order.status = 'arrived';
        s.troops += order.troops;
        const p = PROVINCES.find(p => p.id === order.destination);
        log(s, '新军集结完毕', `${order.name} ${order.troops.toLocaleString()} 人已抵达${p?.capital ?? '开封'}，听候陛下调遣。`, 'military');
      }
    });
  }
  return s;
}

export class GameError extends Error {}
export function applyAction(state: GameState, action: GameAction): { state: GameState; message: string } {
  const s = advanceGame(state);
  const spend = (amount: number) => { if (s.gold < amount) throw new GameError('国库银两不足，请等待赋税入库。'); s.gold -= amount; };
  let message = '已保存';
  switch (action.type) {
    case 'pause': s.paused = !s.paused; s.lastTick = Date.now(); message = s.paused ? '时间已暂停，可从容筹划。' : '天下运转，万象更新。'; break;
    case 'speed': {
      const speed = Number(action.value);
      if (![1, 2, 4].includes(speed)) throw new GameError('无效的时间速度。');
      s.speed = speed; s.lastTick = Date.now(); message = `时间流速已设为 ${speed} 倍`; break;
    }
    case 'resolve': {
      const event = COURT_EVENTS.find(e => e.id === action.eventId);
      const choice = event?.choices.find(c => c.id === action.choiceId);
      if (!event || !choice) throw new GameError('奏折或决策不存在。');
      if (s.resolvedEvents.includes(event.id)) throw new GameError('此奏折已经批复。');
      spend(-choice.gold);
      s.stability = Math.min(100, s.stability + choice.stability);
      s.prestige += choice.prestige;
      if ('income' in choice && typeof choice.income === 'number') s.monthlyIncome += choice.income;
      s.resolvedEvents.push(event.id);
      log(s, `御批 · ${event.title}`, `${choice.text}。${choice.detail}`, 'court');
      message = '圣旨已下，六部即刻奉行。'; break;
    }
    case 'develop': {
      const p = PROVINCES.find(p => p.id === action.provinceId);
      if (!p || p.realm !== '大宋') throw new GameError('只能建设大宋所属领地。');
      const level = s.developments[p.id] ?? 0;
      if (level >= 3) throw new GameError('此地农田已升至最高等级。');
      spend(600 + level * 200); s.developments[p.id] = level + 1; s.monthlyIncome += 40; s.monthlyGrain += 300;
      s.stability = Math.min(100, s.stability + 1);
      log(s, '兴修水利', `${p.name}农田升至 ${level + 1} 级，每月赋税 +40、粮草 +300。`, 'realm');
      message = `${p.capital}水利已扩建，民生渐盛。`; break;
    }
    case 'recruit': {
      const p = PROVINCES.find(p => p.id === action.provinceId) ?? PROVINCES[0];
      if (p.realm !== '大宋') throw new GameError('不能在他国领地征募军队。');
      if (s.orders.filter(o => o.status === 'marching').length >= 3) throw new GameError('当前最多同时征募三支新军。');
      spend(1200);
      if (s.grain < 5000) throw new GameError('粮草不足，无法出兵。');
      s.grain -= 5000;
      s.orders.push({ id: `${Date.now()}`, name: `${p.capital}禁军`, troops: 3000, destination: p.id, startDay: s.day, arrivalDay: s.day + 3, status: 'marching' });
      log(s, '征募禁军', `${p.capital}奉诏征募 3,000 名新军，预计三日后完成集结。`, 'military');
      message = '征募令已下达，新军将在 3 个游戏日后集结。'; break;
    }
    case 'diplomacy': {
      const id = String(action.realmId);
      if (!(id in s.relations)) throw new GameError('未知的邦国。');
      const names: Record<string, string> = { liao: '大辽', xia: '西夏', dali: '大理', goryeo: '高丽' };
      if (action.mode === 'trade') {
        if (s.relations[id] < 30) throw new GameError('关系尚不和睦，请先遣使修好。');
        if (s.tradePartners.includes(id)) throw new GameError('双方已经互通商贸。');
        spend(800); s.tradePartners.push(id); s.monthlyIncome += 120;
        log(s, '互市通商', `与${names[id]}签订互市文书，每月国库收入 +120。`, 'diplomacy'); message = `与${names[id]}的商路已开通。`;
      } else {
        if (s.relations[id] >= 100) throw new GameError('两国关系已达最高。');
        spend(400); s.relations[id] = Math.min(100, s.relations[id] + 20); s.prestige += 15;
        log(s, '使节出访', `遣使携礼出访${names[id]}，两国关系提升 20。`, 'diplomacy'); message = `国书已送达${names[id]}，两国关系有所改善。`;
      }
      break;
    }
    case 'tax': {
      const delta = Number(action.delta);
      if (![1, -1].includes(delta)) throw new GameError('无效的税率。');
      if (s.taxRate + delta < 5 || s.taxRate + delta > 15) throw new GameError('赋税可在 5% 至 15% 之间调整。');
      s.taxRate += delta; s.monthlyIncome += delta * 100; s.stability = Math.max(0, Math.min(100, s.stability - delta * 3));
      log(s, '调整赋税', `朝廷将田赋调整为 ${s.taxRate}%，每月税收${delta > 0 ? '增加' : '减少'} 100。`, 'realm'); message = `田赋已调整为 ${s.taxRate}%`; break;
    }
    case 'reward': {
      const name = String(action.name);
      if (!['高太后', '向皇后', '赵颢'].includes(name)) throw new GameError('宗室成员不存在。');
      if (s.rewards.includes(name)) throw new GameError('本朝已赐予这位宗亲封赏。');
      spend(400); s.rewards.push(name); s.prestige += 40;
      log(s, '恩泽宗亲', `赐${name}金帛，宗室和睦，皇室威望 +40。`, 'court'); message = `赏赐已送至${name}府中。`; break;
    }
    case 'council': {
      const name = String(action.name);
      if (!['王安石', '司马光', '富弼'].includes(name)) throw new GameError('臣子不存在。');
      if (s.council === name) throw new GameError('这位大臣已任宰相。');
      spend(300); s.council = name; s.prestige += 30;
      log(s, '拜相诏书', `诏命${name}出任宰相，总理朝政。`, 'court'); message = `${name}已奉诏拜相。`; break;
    }
    case 'save': message = '山河已入史册，进度已保存。'; break;
    case 'reset': return { state: createGame(), message: '新朝启元，愿陛下开创盛世。' };
    default: throw new GameError('未知的诏令。');
  }
  return { state: s, message };
}
