import { pgTable, uuid, jsonb, timestamp } from 'drizzle-orm/pg-core';
import type { GameState } from '@/lib/game';

export const imperialGames = pgTable('imperial_games', {
  id: uuid('id').primaryKey().defaultRandom(),
  state: jsonb('state').$type<GameState>().notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});
