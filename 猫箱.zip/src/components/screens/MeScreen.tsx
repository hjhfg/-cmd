"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState, type ComponentType, type ReactNode, type SVGProps } from "react";
import { useApp } from "@/components/AppProvider";
import { Avatar, Sheet, toast } from "@/components/ui";
import {
  BellIcon,
  BookIcon,
  ChatSmallIcon,
  CheckIcon,
  ChevronRight,
  ChipIcon,
  CopyIcon,
  EditIcon,
  GearIcon,
  HeartBadgeIcon,
  PlusCircleIcon,
  PuzzleIcon,
  SparkleIcon,
  SpeakerIcon,
  UserCardIcon,
  WandIcon,
} from "@/components/icons";
import { apiGet, apiSend } from "@/lib/api";
import { switchTab } from "@/lib/tabs";

type Glyph = ComponentType<SVGProps<SVGSVGElement>>;

interface Persona {
  id: number;
  name: string;
  description: string;
  avatar: string;
  isDefault: boolean;
}

interface StudioState {
  provider: string;
  model: string;
  hasKey: boolean;
  promptName: string;
  promptOn: boolean;
  books: number;
  entries: number;
  ext: Record<string, boolean>;
}

const INITIAL: StudioState = {
  provider: "built-in",
  model: "",
  hasKey: false,
  promptName: "",
  promptOn: false,
  books: 0,
  entries: 0,
  ext: { autoVoice: true, actionText: true, longMemory: true, worldInfo: true, typingEffect: true },
};

/* ═══════════════════════════════════════════════════════════
   配色：取自「戛台追光」——琥珀主光落在靛黑夜色上，
  四路装配节点各借一味角色题材色（仙侠月白 / 言情绯 / 志怪翠 / 灯火橙）。
   所有正文对深底均 ≥ 5:1。
   ═══════════════════════════════════════════════════════════ */
const STAGE = "#0B0B10";
const SURFACE = "#16161F";
const RAISED = "#1F1F2B";
const LINE = "rgba(255,255,255,0.075)";
const PAPER = "#F7F4EC";
const SUB = "#A9A7BA";
const DIM = "#918FA3";
const KEY = "#FFE500";
const MOON = "#8FA9FF";
const ROSE = "#FF7DA6";
const JADE = "#48DDA0";
const LANTERN = "#FFB25C";
const ALERT = "#FF6B6E";

/** 十六进制转 rgba；不用 color-mix，确保旧内核也能正确渲染节点色 */
function alpha(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
}
/** 把强调色以 a 的比例叠在不透明底色上，得到实色（避免半透明节点透出轨道线） */
function over(hex: string, a: number, base: string) {
  const f = parseInt(hex.slice(1), 16);
  const b = parseInt(base.slice(1), 16);
  const ch = (shift: number) => Math.round((((f >> shift) & 255) * a) + (((b >> shift) & 255) * (1 - a)));
  return `rgb(${ch(16)}, ${ch(8)}, ${ch(0)})`;
}

const EXT_LABELS: Record<string, string> = {
  autoVoice: "语音",
  actionText: "动作",
  longMemory: "长记忆",
  worldInfo: "世界书",
  typingEffect: "打字机",
};

/* ───────────────────────── 零件 ───────────────────────── */

function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={`overflow-hidden rounded-[20px] ${className}`}
      style={{ background: SURFACE, boxShadow: `inset 0 0 0 1px ${LINE}` }}
    >
      {children}
    </div>
  );
}

function Label({ zh, en, right }: { zh: string; en: string; right?: ReactNode }) {
  return (
    <div className="mb-2.5 flex items-end justify-between gap-3 px-1.5">
      <div className="flex items-baseline gap-2">
        <h2 className="text-[15px] font-bold tracking-[-0.01em]" style={{ color: PAPER }}>
          {zh}
        </h2>
        <span className="font-mono text-[9px] tracking-[0.22em]" style={{ color: "rgba(255,255,255,0.26)" }}>
          {en}
        </span>
      </div>
      {right}
    </div>
  );
}

function Row({
  icon: Icon,
  tint,
  title,
  detail,
  href,
  onClick,
  trailing,
  badge,
  last,
}: {
  icon: Glyph;
  tint: string;
  title: string;
  detail?: string;
  href?: string;
  onClick?: () => void;
  trailing?: ReactNode;
  badge?: number;
  last?: boolean;
}) {
  const body = (
    <>
      <span className="grid h-[34px] w-[34px] shrink-0 place-items-center rounded-[11px]" style={{ background: RAISED, color: tint }}>
        <Icon className="h-[17px] w-[17px]" strokeWidth={1.8} />
      </span>
      <span className={`flex min-w-0 flex-1 items-center gap-3 py-[13px] pr-4 ${last ? "" : "border-b"}`} style={{ borderColor: LINE }}>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2 text-[14.5px] font-medium" style={{ color: PAPER }}>
            {title}
            {!!badge && badge > 0 && (
              <span
                className="inline-flex h-[17px] min-w-[17px] items-center justify-center rounded-full px-1.5 text-[10px] font-bold leading-none"
                style={{ background: ALERT, color: "#1A0B0C" }}
              >
                {badge > 99 ? "99+" : badge}
              </span>
            )}
          </span>
          {detail && (
            <span className="mt-[2px] block truncate text-[11.5px]" style={{ color: DIM }}>
              {detail}
            </span>
          )}
        </span>
        {trailing ?? <ChevronRight className="h-4 w-4 shrink-0" style={{ color: "rgba(255,255,255,0.24)" }} />}
      </span>
    </>
  );
  const cls = "flex w-full items-center gap-3 pl-4 text-left transition-colors duration-150 active:bg-white/[0.045]";
  return href ? <Link href={href} className={cls}>{body}</Link> : <button type="button" onClick={onClick} className={cls}>{body}</button>;
}

function Toggle({ on }: { on: boolean }) {
  return (
    <span
      role="switch"
      aria-checked={on}
      className="relative h-[27px] w-[47px] shrink-0 rounded-full transition-colors duration-200"
      style={{ background: on ? KEY : "rgba(255,255,255,0.16)" }}
    >
      <span
        className="absolute top-[3px] h-[21px] w-[21px] rounded-full transition-all duration-200"
        style={{ left: on ? 23 : 3, background: on ? "#14140F" : "#E6E4EE", boxShadow: "0 1px 3px rgba(0,0,0,.4)" }}
      />
    </span>
  );
}

/** 装配轨道上的一节：编号光盘 + 连接线 + 可点行 */
function RailNode({
  index,
  icon: Icon,
  tint,
  title,
  detail,
  href,
  active,
  isLast,
  terminal,
}: {
  index: number;
  icon: Glyph;
  tint: string;
  title: string;
  detail: string;
  href: string;
  active: boolean;
  isLast?: boolean;
  terminal?: boolean;
}) {
  return (
    <div className="relative pl-[52px]">
      {/* 轨道竖线 */}
      {!isLast && (
        <span
          aria-hidden
          className="absolute left-[19px] top-[42px] bottom-[-6px] w-[2px] overflow-hidden rounded-full"
          style={{ background: "rgba(255,255,255,0.09)" }}
        >
          {active && <span className="stage-rail absolute inset-0" />}
        </span>
      )}
      {/* 节点光盘 */}
      <span
        aria-hidden
        className="absolute left-0 top-[9px] grid h-[40px] w-[40px] place-items-center rounded-[13px] transition-colors duration-300"
        style={{
          background: active ? over(tint, 0.16, RAISED) : RAISED,
          color: active ? tint : "rgba(255,255,255,0.34)",
          boxShadow: active ? `inset 0 0 0 1px ${alpha(tint, 0.4)}` : `inset 0 0 0 1px ${LINE}`,
        }}
      >
        <Icon className="h-[18px] w-[18px]" strokeWidth={1.85} />
        <span
          className="absolute -left-[3px] -top-[3px] grid h-[15px] w-[15px] place-items-center rounded-full font-mono text-[8.5px] font-bold"
          style={{
            background: active ? tint : "#2A2A38",
            color: active ? "#12121A" : "rgba(255,255,255,0.45)",
          }}
        >
          {terminal ? "▸" : index}
        </span>
      </span>

      <Link
        href={href}
        className="flex items-center gap-3 rounded-[14px] py-[13px] pr-3 transition-colors duration-150 active:bg-white/[0.05]"
      >
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2">
            <span className="text-[14.5px] font-semibold" style={{ color: PAPER }}>{title}</span>
            <span
              className="rounded px-1.5 py-[1px] text-[9.5px] font-bold"
              style={{
                background: active ? alpha(tint, 0.18) : "rgba(255,255,255,0.07)",
                color: active ? tint : DIM,
              }}
            >
              {terminal ? (active ? "自定义" : "内置") : active ? "已装配" : "未启用"}
            </span>
          </span>
          <span className="mt-[3px] block truncate text-[11.5px]" style={{ color: DIM }}>{detail}</span>
        </span>
        <ChevronRight className="h-4 w-4 shrink-0" style={{ color: "rgba(255,255,255,0.24)" }} />
      </Link>
    </div>
  );
}

/* ───────────────────────────── 页面 ───────────────────────────── */

export default function MeScreen({ visible }: { visible: boolean }) {
  const { user, unread, refresh, autoVoice, setAutoVoice } = useApp();
  const [personas, setPersonas] = useState<Persona[] | null>(null);
  const [studio, setStudio] = useState<StudioState>(INITIAL);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [aboutOpen, setAboutOpen] = useState(false);
  const railRef = useRef<HTMLElement | null>(null);

  const load = useCallback(async () => {
    const [p, a, pr, w, e] = await Promise.allSettled([
      apiGet<{ items: Persona[] }>("/api/studio?scope=personas"),
      apiGet<{ provider: string; model: string; hasKey: boolean }>("/api/studio?scope=api"),
      apiGet<{ items: { name: string; isActive: boolean }[] }>("/api/studio?scope=prompts"),
      apiGet<{ books: { id: number; enabled: boolean }[]; entries: { bookId: number; enabled: boolean }[] }>("/api/studio?scope=world"),
      apiGet<Record<string, boolean>>("/api/studio?scope=extensions"),
    ]);

    setPersonas(p.status === "fulfilled" ? [...(p.value.items ?? [])].sort((x, y) => x.id - y.id) : []);

    setStudio((prev) => {
      const next = { ...prev };
      if (a.status === "fulfilled") {
        next.provider = a.value.provider || "built-in";
        next.model = a.value.model || "";
        next.hasKey = Boolean(a.value.hasKey);
      }
      if (pr.status === "fulfilled") {
        const on = pr.value.items?.find((x) => x.isActive);
        next.promptOn = Boolean(on);
        next.promptName = on?.name || "";
      }
      if (w.status === "fulfilled") {
        const ids = new Set((w.value.books ?? []).filter((b) => b.enabled).map((b) => b.id));
        next.books = ids.size;
        next.entries = (w.value.entries ?? []).filter((x) => x.enabled && ids.has(x.bookId)).length;
      }
      if (e.status === "fulfilled") next.ext = { ...next.ext, ...(e.value ?? {}) };
      return next;
    });
  }, []);

  // 标签页保活：只在切回时静默同步，不出现加载态
  const wasVisible = useRef(visible);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    if (visible && !wasVisible.current) { void refresh(); void load(); }
    wasVisible.current = visible;
  }, [visible, refresh, load]);

  const current = personas?.find((p) => p.isDefault) ?? personas?.[0] ?? null;
  const portrait = current?.avatar || "";

  const customModel = studio.provider !== "built-in" && (studio.hasKey || studio.provider === "custom");
  const modelLabel = customModel ? studio.model || studio.provider : "内置引擎";
  const extOn = useMemo(
    () => Object.entries(studio.ext).filter(([, v]) => v).map(([k]) => EXT_LABELS[k] ?? k),
    [studio.ext],
  );
  const sources = [
    { key: "p", label: "人设", tint: KEY, on: Boolean(current) },
    { key: "w", label: "提示", tint: ROSE, on: studio.promptOn },
    { key: "b", label: "世界", tint: JADE, on: studio.books > 0 },
    { key: "e", label: "扩展", tint: LANTERN, on: extOn.length > 0 },
  ];
  const assembled = sources.filter((s) => s.on).length;

  async function pickPersona(p: Persona) {
    if (p.isDefault || busyId !== null) return;
    const backup = personas;
    setBusyId(p.id);
    setPersonas((list) => list?.map((x) => ({ ...x, isDefault: x.id === p.id })) ?? list);
    try {
      await apiSend("/api/studio", { scope: "personas", action: "default", id: p.id });
      await load();
      toast(`已切换为「${p.name}」`);
    } catch {
      setPersonas(backup);
      toast("切换失败，请重试");
    } finally {
      setBusyId(null);
    }
  }

  async function copyId() {
    if (!user?.code) return;
    try {
      await navigator.clipboard.writeText(user.code);
      toast("猫箱号已复制");
    } catch {
      toast(`猫箱号：${user.code}`);
    }
  }

  return (
    <div className="flex h-full flex-col" style={{ background: STAGE, color: PAPER }}>
      <div className="stage-scroll min-h-0 flex-1 overflow-y-auto overscroll-contain">
        {/* ══════════════ 登场舞台 ══════════════ */}
        <section className="relative overflow-hidden pb-6">
          {/* 立绘：右侧大幅出血，向左溶入夜色 */}
          {portrait && (
            <div key={current?.id} className="stage-portrait pointer-events-none absolute inset-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={portrait} alt="" aria-hidden className="absolute inset-y-0 right-0 h-full w-[74%] object-cover object-top" />
              <div
                aria-hidden
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(100deg, #0B0B10 26%, rgba(11,11,16,.94) 44%, rgba(11,11,16,.62) 64%, rgba(11,11,16,.34) 82%, rgba(11,11,16,.55) 100%)",
                }}
              />
              <div aria-hidden className="absolute inset-x-0 bottom-0 h-40" style={{ background: "linear-gradient(to top, #0B0B10 18%, rgba(11,11,16,.7) 55%, transparent)" }} />
            </div>
          )}
          {/* 追光 + 光晕 + 颗粒 */}
          <div aria-hidden className="stage-glow pointer-events-none absolute inset-0" />
          <div aria-hidden className="stage-spot pointer-events-none absolute inset-0" />
          <div aria-hidden className="stage-grain pointer-events-none absolute inset-0 opacity-[0.16] mix-blend-overlay" />

          {/* 顶栏 */}
          <header className="relative flex items-center justify-between px-5 pt-6">
            <div className="flex items-center gap-2.5">
              <h1 className="text-[24px] font-black leading-none tracking-[-0.04em]">我的</h1>
              <span className="rounded-full px-2 py-[3px] text-[9.5px] font-bold tracking-[0.14em]" style={{ background: "rgba(255,229,0,.14)", color: KEY }}>
                LOCAL
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Link
                href="/messages/interactions"
                aria-label="互动消息"
                className="relative grid h-9 w-9 place-items-center rounded-full backdrop-blur-md transition active:scale-95"
                style={{ background: "rgba(255,255,255,.09)", boxShadow: `inset 0 0 0 1px ${LINE}`, color: PAPER }}
              >
                <BellIcon className="h-[18px] w-[18px]" strokeWidth={1.8} />
                {unread > 0 && (
                  <span className="absolute right-[7px] top-[7px] h-[7px] w-[7px] rounded-full" style={{ background: ALERT, boxShadow: `0 0 0 2px ${STAGE}` }} />
                )}
              </Link>
              <Link
                href="/settings"
                aria-label="设置"
                className="grid h-9 w-9 place-items-center rounded-full backdrop-blur-md transition active:scale-95"
                style={{ background: "rgba(255,255,255,.09)", boxShadow: `inset 0 0 0 1px ${LINE}`, color: PAPER }}
              >
                <GearIcon className="h-[18px] w-[18px]" strokeWidth={1.8} />
              </Link>
            </div>
          </header>

          {/* 身份信息 */}
          <div className="relative mt-8 px-5">
            <div className="stage-rise flex items-center gap-2" style={{ animationDelay: "40ms" }}>
              <span className="stage-live h-[6px] w-[6px] rounded-full" style={{ background: KEY }} />
              <span className="font-mono text-[10px] tracking-[0.24em]" style={{ color: KEY }}>
                {current ? "ON STAGE" : "BACKSTAGE"}
              </span>
              <span className="text-[10px]" style={{ color: DIM }}>
                {current ? "登场中" : "候场"}
              </span>
            </div>

            <h2
              className="stage-rise mt-2.5 text-[34px] font-black leading-[1.08] tracking-[-0.045em]"
              style={{ animationDelay: "90ms", textShadow: "0 3px 20px rgba(0,0,0,.7)" }}
            >
              {current?.name || (personas === null ? user?.nickname || "猫箱用户" : "尚未登场")}
            </h2>
            <span className="stage-rise mt-2.5 block h-[3px] w-11 rounded-full" style={{ animationDelay: "130ms", background: KEY }} />

            {/* 台词式人设描述 */}
            <div className="stage-rise mt-3.5 max-w-[76%] border-l-2 pl-3" style={{ animationDelay: "170ms", borderColor: "rgba(255,229,0,.4)" }}>
              <p className="line-clamp-3 text-[12.5px] leading-[1.75]" style={{ color: SUB, textShadow: "0 1px 10px rgba(0,0,0,.65)" }}>
                {current
                  ? current.description || "还没有写下人设。补上外貌、身份与性格，AI 才会在每场戏里记得你是谁。"
                  : personas === null
                    ? user?.bio || "这里是你在故事中的身份档案。"
                    : "定义一张人设卡，让每段对话都知道该与谁说话。"}
              </p>
            </div>

            {/* 档案元信息 */}
            <div className="stage-rise mt-4 flex flex-wrap items-center gap-1.5" style={{ animationDelay: "210ms" }}>
              <span className="rounded-md px-2 py-[3px] font-mono text-[10px] backdrop-blur-md" style={{ background: "rgba(0,0,0,.42)", color: KEY, boxShadow: `inset 0 0 0 1px rgba(255,229,0,.22)` }}>
                {"{{user}}"}
              </span>
              <button
                type="button"
                onClick={() => void copyId()}
                aria-label="复制猫箱号"
                className="inline-flex items-center gap-1 rounded-md px-2 py-[3px] font-mono text-[10px] backdrop-blur-md transition active:opacity-70"
                style={{ background: "rgba(0,0,0,.42)", color: SUB, boxShadow: `inset 0 0 0 1px ${LINE}` }}
              >
                ID {user?.code || "······"}
                <CopyIcon className="h-2.5 w-2.5" />
              </button>
              {current && (
                <span className="rounded-md px-2 py-[3px] font-mono text-[10px] backdrop-blur-md" style={{ background: "rgba(0,0,0,.42)", color: SUB, boxShadow: `inset 0 0 0 1px ${LINE}` }}>
                  {current.description.length} 字
                </span>
              )}
              <Link
                href="/me/edit"
                className="inline-flex items-center gap-1 rounded-md px-2 py-[3px] text-[10px] backdrop-blur-md transition active:opacity-70"
                style={{ background: "rgba(0,0,0,.42)", color: SUB, boxShadow: `inset 0 0 0 1px ${LINE}` }}
              >
                <EditIcon className="h-2.5 w-2.5" />
                账号资料
              </Link>
            </div>

            {/* 装配速览：首屏即可读出「这局戏带了什么上台」，点击直达轨道 */}
            <button
              type="button"
              onClick={() => railRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })}
              aria-label="查看上下文装配详情"
              className="stage-rise mt-4 flex w-full items-center gap-2.5 rounded-[13px] px-3 py-[9px] backdrop-blur-md transition active:scale-[0.99]"
              style={{ animationDelay: "235ms", background: "rgba(0,0,0,.44)", boxShadow: `inset 0 0 0 1px ${LINE}` }}
            >
              <span className="font-mono text-[9px] tracking-[0.18em]" style={{ color: "rgba(255,255,255,.34)" }}>
                RIG
              </span>
              <span className="flex min-w-0 flex-1 items-center gap-2.5 overflow-hidden">
                {sources.map((s) => (
                  <span key={s.key} className="flex shrink-0 items-center gap-1">
                    <span
                      className="h-[5px] w-[5px] rounded-full transition-colors duration-300"
                      style={{ background: s.on ? s.tint : "rgba(255,255,255,.2)", boxShadow: s.on ? `0 0 6px ${alpha(s.tint, 0.85)}` : undefined }}
                    />
                    <span className="text-[11px] transition-colors duration-300" style={{ color: s.on ? PAPER : "rgba(255,255,255,.36)" }}>
                      {s.label}
                    </span>
                  </span>
                ))}
              </span>
              <span className="shrink-0 font-mono text-[10.5px] font-bold" style={{ color: KEY }}>
                {assembled}/4
              </span>
              <ChevronRight className="h-3.5 w-3.5 shrink-0" style={{ color: "rgba(255,255,255,.3)" }} />
            </button>

            {/* 主操作 */}
            <div className="stage-rise mt-3 flex flex-col gap-2" style={{ animationDelay: "270ms" }}>
              <Link
                href="/personas"
                className="flex h-[46px] items-center justify-center gap-2 rounded-[15px] text-[14.5px] font-bold transition active:scale-[0.985]"
                style={{ background: KEY, color: "#14140F", boxShadow: "0 10px 30px -12px rgba(255,229,0,.7)" }}
              >
                <UserCardIcon className="h-[18px] w-[18px]" strokeWidth={2} />
                设定管理
              </Link>
              <Link
                href="/personas?new=1"
                className="flex h-[40px] items-center justify-center gap-1.5 rounded-[13px] text-[13px] font-medium backdrop-blur-md transition active:scale-[0.985]"
                style={{ background: "rgba(255,255,255,.08)", color: PAPER, boxShadow: `inset 0 0 0 1px ${LINE}` }}
              >
                <PlusCircleIcon className="h-4 w-4" />
                新建人设
              </Link>
            </div>
          </div>
        </section>

        {/* ══════════════ 人设胶片（仅已创建的人设，无模板） ══════════════ */}
        {personas !== null && personas.length > 0 && (
          <section className="stage-rise mt-1 pb-1" style={{ animationDelay: "300ms" }}>
            <div className="mb-2 flex items-baseline justify-between px-5">
              <div className="flex items-baseline gap-2">
                <h2 className="text-[13.5px] font-bold" style={{ color: PAPER }}>角色抽屉</h2>
                <span className="font-mono text-[9px] tracking-[0.2em]" style={{ color: "rgba(255,255,255,.26)" }}>CAST</span>
              </div>
              <Link href="/personas" className="inline-flex items-center gap-0.5 text-[11.5px] transition active:opacity-60" style={{ color: DIM }}>
                全部 {personas.length}
                <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {/* 胶片齿孔 */}
            <div
              aria-hidden
              className="mx-4 h-[7px] rounded-t-[4px]"
              style={{
                background: "repeating-linear-gradient(to right, rgba(255,255,255,.14) 0 5px, transparent 5px 13px)",
                backgroundColor: "rgba(255,255,255,.03)",
              }}
            />
            <div className="stage-strip mx-4 flex gap-2.5 overflow-x-auto px-3 py-3" style={{ background: "rgba(255,255,255,.03)" }}>
              {personas.map((p) => {
                const on = p.isDefault || (!personas.some((x) => x.isDefault) && p.id === current?.id);
                return (
                  <button
                    key={p.id}
                    type="button"
                    disabled={busyId !== null}
                    aria-label={`切换人设：${p.name}`}
                    aria-pressed={on}
                    onClick={() => void pickPersona(p)}
                    className="group w-[68px] shrink-0 transition active:scale-95 disabled:opacity-60"
                  >
                    <span
                      className="relative block h-[88px] w-[68px] overflow-hidden rounded-[11px] transition-all duration-300"
                      style={{
                        boxShadow: on ? `0 0 0 2px ${KEY}, 0 8px 20px -8px rgba(255,229,0,.6)` : `inset 0 0 0 1px ${LINE}`,
                        filter: on ? "none" : "saturate(.55) brightness(.72)",
                      }}
                    >
                      {p.avatar ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.avatar} alt="" className="h-full w-full object-cover object-top" />
                      ) : (
                        <span className="grid h-full w-full place-items-center text-[22px] font-black" style={{ background: RAISED, color: SUB }}>
                          {p.name.slice(0, 1)}
                        </span>
                      )}
                      {on && (
                        <span className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-0.5 py-[3px] text-[9px] font-bold" style={{ background: KEY, color: "#14140F" }}>
                          <CheckIcon className="h-2.5 w-2.5" strokeWidth={3.5} />
                          登场
                        </span>
                      )}
                    </span>
                    <span className="mt-1.5 block truncate text-center text-[11px]" style={{ color: on ? PAPER : DIM, fontWeight: on ? 700 : 400 }}>
                      {p.name}
                    </span>
                  </button>
                );
              })}
              <Link href="/personas?new=1" className="w-[68px] shrink-0 transition active:scale-95">
                <span className="grid h-[88px] w-[68px] place-items-center rounded-[11px] border border-dashed" style={{ borderColor: "rgba(255,255,255,.2)", color: DIM }}>
                  <PlusCircleIcon className="h-5 w-5" />
                </span>
                <span className="mt-1.5 block text-center text-[11px]" style={{ color: DIM }}>新建</span>
              </Link>
            </div>
            <div
              aria-hidden
              className="mx-4 h-[7px] rounded-b-[4px]"
              style={{
                background: "repeating-linear-gradient(to right, rgba(255,255,255,.14) 0 5px, transparent 5px 13px)",
                backgroundColor: "rgba(255,255,255,.03)",
              }}
            />
          </section>
        )}

        {/* ══════════════ 上下文装配轨道 ══════════════ */}
        <section ref={railRef} className="stage-rise mt-7 scroll-mt-3 px-4" style={{ animationDelay: "340ms" }}>
          <Label
            zh="上下文装配"
            en="CONTEXT"
            right={
              <span className="rounded-full px-2 py-[3px] text-[10.5px] font-bold" style={{ background: "rgba(255,229,0,.13)", color: KEY }}>
                {assembled}/4 已装配
              </span>
            }
          />
          <Panel className="px-4 pb-2 pt-2">
            <p className="px-0.5 pb-2.5 pt-1 text-[11.5px] leading-relaxed" style={{ color: DIM }}>
              下一条消息发出时，以下内容会按顺序注入模型。点亮起的节点即为生效项。
            </p>
            <RailNode
              index={1}
              icon={UserCardIcon}
              tint={KEY}
              title="用户人设"
              detail={current ? `${current.name} · ${current.description.length} 字身份描述` : "未设置 · AI 还不知道你是谁"}
              href="/personas"
              active={Boolean(current)}
            />
            <RailNode
              index={2}
              icon={WandIcon}
              tint={ROSE}
              title="提示词"
              detail={studio.promptOn ? `${studio.promptName} · 定义叙事口吻` : "默认风格 · 未启用自定义预设"}
              href="/prompts"
              active={studio.promptOn}
            />
            <RailNode
              index={3}
              icon={BookIcon}
              tint={JADE}
              title="世界书"
              detail={studio.books > 0 ? `${studio.books} 本启用 · ${studio.entries} 个条目待命中` : "未启用 · 关键词触发的世界观"}
              href="/worldbook"
              active={studio.books > 0}
            />
            <RailNode
              index={4}
              icon={PuzzleIcon}
              tint={LANTERN}
              title="扩展"
              detail={extOn.length > 0 ? `${extOn.length}/5 · ${extOn.join(" · ")}` : "全部关闭"}
              href="/extensions"
              active={extOn.length > 0}
            />
            <RailNode
              index={5}
              icon={ChipIcon}
              tint={MOON}
              title="AIP 设置"
              detail={customModel ? `${modelLabel} · 自定义端点` : "内置引擎 · 可接入自己的模型"}
              href="/aip"
              active={customModel}
              isLast
              terminal
            />
          </Panel>
        </section>

        {/* ══════════════ 常用 ══════════════ */}
        <section className="stage-rise mt-7 px-4" style={{ animationDelay: "380ms" }}>
          <Label zh="常用" en="SHORTCUTS" />
          <Panel>
            <Row icon={ChatSmallIcon} tint={MOON} title="我的聊天" detail="继续进行中的角色对话与剧情" onClick={() => switchTab("/messages")} />
            <Row
              icon={BellIcon}
              tint={ROSE}
              title="互动消息"
              detail={unread > 0 ? `${unread} 条未读` : "点赞、评论与系统通知"}
              badge={unread}
              href="/messages/interactions"
            />
            <Row icon={SparkleIcon} tint={LANTERN} title="创作中心" detail="创建角色、编排多章节故事" onClick={() => switchTab("/create")} last />
          </Panel>
        </section>

        {/* ══════════════ 偏好 ══════════════ */}
        <section className="stage-rise mt-7 px-4 pb-10" style={{ animationDelay: "420ms" }}>
          <Label zh="偏好" en="PREFERENCES" />
          <Panel>
            <Row
              icon={SpeakerIcon}
              tint={JADE}
              title="角色语音朗读"
              detail={autoVoice ? "新回复自动播报" : "已关闭 · 点气泡可手动播报"}
              onClick={() => setAutoVoice(!autoVoice)}
              trailing={<Toggle on={Boolean(autoVoice)} />}
            />
            <Row icon={HeartBadgeIcon} tint={ROSE} title="内容推荐偏好" detail="按题材调整首页推荐" href="/" />
            <Row icon={UserCardIcon} tint={KEY} title="账号资料" detail="头像、昵称与签名" href="/me/edit" />
            <Row icon={GearIcon} tint={SUB} title="通用设置" detail="缓存清理与本地身份" href="/settings" />
            <Row icon={BookIcon} tint={MOON} title="关于猫箱" detail="本地角色扮演与叙事空间" onClick={() => setAboutOpen(true)} last />
          </Panel>

          <p className="mt-7 text-center text-[10.5px] leading-relaxed" style={{ color: "rgba(255,255,255,.3)" }}>
            角色与剧情内容由 AI 生成，请理性看待
          </p>
        </section>
      </div>

      <Sheet dark open={aboutOpen} onClose={() => setAboutOpen(false)} title="关于猫箱">
        <div className="space-y-3 px-5 pb-8 text-[14px] leading-[1.85]" style={{ color: SUB }}>
          <p>猫箱是一个角色互动与故事共创空间。你可以与不同角色聊天、推进多章节剧情，也可以亲手创作角色与故事。</p>
          <p>
            「设定管理」参考酒馆（SillyTavern）的 Persona 机制：多张人设卡、默认人设、对话内单独指定。
            「上下文装配」把下一条消息真正会注入的内容摊开给你看——人设、提示词、世界书、扩展，逐节可查可改。
          </p>
          <p className="text-[12px]" style={{ color: DIM }}>
            所有角色与对话内容均由人工智能生成，与现实人物无关。
          </p>
        </div>
      </Sheet>
    </div>
  );
}